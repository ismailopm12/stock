import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { StockStatus } from "@/lib/inventory";

export function PageHeader({ title, subtitle, action, icon: Icon }: { title: string; subtitle?: string; action?: ReactNode; icon?: LucideIcon }) {
  return (
    <header className={cn("grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 pt-6 pb-4", Icon && "professional-header")} >
      <div className="flex min-w-0 items-center gap-3">
        {Icon && <span className="screen-symbol"><Icon className="h-6 w-6" /></span>}
        <div className="min-w-0"><h1 className="break-words text-2xl font-extrabold">{title}</h1>
        {subtitle && <p className="truncate text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {action}
    </header>
  );
}

export function StatusBadge({ s }: { s: StockStatus }) {
  const map = {
    in: ["In Stock", "bg-success-soft text-success"],
    low: ["Low Stock", "bg-warning-soft text-warning"],
    out: ["Out of Stock", "bg-danger-soft text-destructive"],
  } as const;
  return <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold", map[s][1])}>{map[s][0]}</span>;
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="mx-5 flex flex-col items-center gap-2 py-12 text-center">
      <p className="font-semibold">{title}</p>
      {hint && <p className="text-sm text-muted-foreground">{hint}</p>}
      {action}
    </div>
  );
}
