import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ArrowDownLeft, ArrowUpRight, ClipboardCheck, LoaderCircle, Minus, Plus, ScanBarcode, Trash2, Keyboard } from "lucide-react";
import { genBatchNo, itemsQuery, recordMovement, totalQty, type Item } from "@/lib/inventory";
import { planAudit, planOut, type PlanStep } from "@/lib/scan-session";
import { validateQuantity } from "@/lib/item-units";
import { Scanner } from "@/components/app/Scanner";
import { BatchDateField } from "@/components/app/BatchDateField";
import { PageHeader } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/scan")({
  head: () => ({ meta: [{ title: "Scan stock — Sujon" }, { name: "description", content: "Scan barcodes with your camera to stock in, stock out or audit items." }, { property: "og:title", content: "Scan stock — Sujon" }, { property: "og:description", content: "Barcode scanning for stock in, out and audits." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(itemsQuery),
  component: ScanPage,
});

type Mode = "in" | "out" | "audit";
const modes: { k: Mode; label: string; icon: typeof Plus; tone: string }[] = [
  { k: "in", label: "Stock in", icon: ArrowDownLeft, tone: "bg-success-soft text-success" },
  { k: "out", label: "Stock out", icon: ArrowUpRight, tone: "bg-danger-soft text-destructive" },
  { k: "audit", label: "Audit", icon: ClipboardCheck, tone: "bg-primary-soft text-accent-foreground" },
];

function ScanPage() {
  const { data: items } = useSuspenseQuery(itemsQuery);
  const qc = useQueryClient();
  const [mode, setMode] = useState<Mode>("in");
  const [rows, setRows] = useState<{ id: string; qty: string }[]>([]);
  const [batchNo, setBatchNo] = useState(genBatchNo);
  const [manual, setManual] = useState("");
  const [busy, setBusy] = useState(false);
  const [camera, setCamera] = useState(true);
  const [flash, setFlash] = useState<string | null>(null);

  const byCode = useMemo(() => {
    const m = new Map<string, Item>();
    items.forEach((i) => { if (i.barcode) m.set(i.barcode, i); if (i.sku) m.set(i.sku.trim().toLowerCase(), i); });
    return m;
  }, [items]);
  const itemById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);

  function handle(code: string) {
    const item = byCode.get(code) ?? byCode.get(code.toLowerCase());
    if (!item) { toast.error(`No item with barcode ${code}`); return; }
    setRows((r) => {
      const ex = r.find((x) => x.id === item.id);
      if (ex) return r.map((x) => x.id === item.id ? { ...x, qty: String(Math.round((Number(x.qty || 0) + 1) * 1000) / 1000) } : x);
      return [{ id: item.id, qty: "1" }, ...r];
    });
    setFlash(item.id); setTimeout(() => setFlash(null), 600);
    toast.success(`${item.name} +1`, { duration: 1200 });
  }

  const bump = (id: string, d: number) => setRows((r) => r.map((x) => x.id === id ? { ...x, qty: String(Math.max(0, Math.round((Number(x.qty || 0) + d) * 1000) / 1000)) } : x));

  async function apply() {
    if (busy || !rows.length) return;
    if (mode === "in" && !batchNo.trim()) { toast.error("Enter a batch number"); return; }
    setBusy(true);
    const failed: typeof rows = [];
    let done = 0;
    for (const row of rows) {
      const item = itemById.get(row.id);
      if (!item) continue;
      try {
        const qty = validateQuantity(row.qty, item.unit);
        if (mode !== "audit" && qty <= 0) throw new Error("Quantity must be above 0");
        const steps: PlanStep[] = mode === "in" ? [{ batch_no: batchNo.trim(), type: "in", qty }]
          : mode === "out" ? planOut(item.batches, qty) : planAudit(item.batches, qty, batchNo.trim() || genBatchNo());
        const note = mode === "audit" ? `Audit count: ${qty}` : "Barcode scan";
        for (const s of steps) await recordMovement({ item_id: item.id, batch_no: s.batch_no, type: s.type, qty: s.qty, note });
        done++;
      } catch (e) {
        failed.push(row);
        toast.error(`${item.name}: ${e instanceof Error ? e.message : "failed"}`);
      }
    }
    await qc.invalidateQueries({ queryKey: ["items"] });
    await qc.invalidateQueries({ queryKey: ["movements"] });
    setRows(failed);
    setBusy(false);
    if (done) toast.success(`${done} item${done > 1 ? "s" : ""} updated${failed.length ? ` · ${failed.length} need attention` : ""}`);
    if (mode === "in" && !failed.length) setBatchNo(genBatchNo());
  }

  const current = modes.find((m) => m.k === mode)!;

  return (
    <div className="pb-8">
      <PageHeader icon={ScanBarcode} title="Scan stock" subtitle="Camera barcode scanner" action={<Button asChild variant="outline" size="sm" className="rounded-xl"><Link to="/barcodes">Labels</Link></Button>} />
      <div className="space-y-4 px-5">
        <div className="grid grid-cols-3 gap-1 rounded-2xl bg-muted p-1">
          {modes.map((m) => (
            <Button key={m.k} variant="ghost" aria-pressed={mode === m.k} onClick={() => setMode(m.k)}
              className={cn("h-11 rounded-xl text-xs font-semibold sm:text-sm", mode === m.k ? "bg-card shadow-soft" : "text-muted-foreground")}>
              <m.icon className="h-4 w-4" />{m.label}
            </Button>
          ))}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <Scanner onScan={handle} paused={!camera} />
            <div className="flex gap-2">
              <form className="relative flex-1" onSubmit={(e) => { e.preventDefault(); if (manual.trim()) { handle(manual.trim()); setManual(""); } }}>
                <Keyboard className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input aria-label="Type barcode or SKU" value={manual} onChange={(e) => setManual(e.target.value)} placeholder="Type barcode / SKU, or use a USB scanner" className="h-11 rounded-xl bg-card pl-9" />
              </form>
              <Button variant="outline" className="h-11 rounded-xl" onClick={() => setCamera(!camera)}>{camera ? "Pause" : "Camera"}</Button>
            </div>
            {mode !== "out" && (
              <BatchDateField id="scan-batch" value={batchNo} onChange={setBatchNo}
                label={mode === "in" ? "Batch date for received stock" : "Batch date for extra stock found"} />
            )}
            <p className="rounded-xl bg-muted p-3 text-xs text-muted-foreground">
              {mode === "in" && "Each scan adds 1 to the received quantity. Stock goes into the batch above."}
              {mode === "out" && "Each scan adds 1. Stock is taken from the earliest-expiring batches first."}
              {mode === "audit" && "Scan every unit you physically count. Applying sets stock to your counted amount."}
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-bold">Scanned items <span className="text-muted-foreground">({rows.length})</span></h2>
              {!!rows.length && <Button variant="ghost" size="sm" onClick={() => setRows([])}>Clear</Button>}
            </div>
            {!rows.length && <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground"><ScanBarcode className="mx-auto mb-2 h-8 w-8 animated-icon" />Point the camera at a barcode</div>}
            {rows.map((row) => {
              const item = itemById.get(row.id);
              if (!item) return null;
              const onHand = totalQty(item);
              const diff = mode === "audit" ? Math.round((Number(row.qty || 0) - onHand) * 1000) / 1000 : 0;
              return (
                <div key={row.id} className={cn("native-list-item rounded-2xl border border-border bg-card p-3 transition-shadow", flash === row.id && "ring-2 ring-primary")}>
                  <div className="flex items-start gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{item.name}</p>
                      <p className="text-xs text-muted-foreground">On hand {onHand} {item.unit}{mode === "audit" && <> · <span className={diff === 0 ? "text-success" : diff > 0 ? "text-success" : "text-destructive"}>{diff === 0 ? "matches" : `${diff > 0 ? "+" : ""}${diff}`}</span></>}</p>
                    </div>
                    <Button variant="ghost" size="icon" aria-label={`Remove ${item.name}`} onClick={() => setRows((r) => r.filter((x) => x.id !== row.id))}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Button variant="outline" size="icon" aria-label="Decrease" onClick={() => bump(row.id, -1)} className="rounded-xl"><Minus className="h-4 w-4" /></Button>
                    <Input aria-label={`${item.name} quantity`} value={row.qty} onChange={(e) => setRows((r) => r.map((x) => x.id === row.id ? { ...x, qty: e.target.value } : x))} className="h-10 flex-1 rounded-xl text-center font-bold tabular-nums" />
                    <Button variant="outline" size="icon" aria-label="Increase" onClick={() => bump(row.id, 1)} className="rounded-xl"><Plus className="h-4 w-4" /></Button>
                    <span className="w-10 text-xs text-muted-foreground">{item.unit}</span>
                  </div>
                </div>
              );
            })}
            {!!rows.length && (
              <Button disabled={busy} onClick={apply} className="h-12 w-full rounded-2xl text-base font-semibold shadow-glow">
                {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <current.icon className="h-4 w-4" />}
                {busy ? "Saving…" : `Apply ${current.label.toLowerCase()} (${rows.length})`}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
