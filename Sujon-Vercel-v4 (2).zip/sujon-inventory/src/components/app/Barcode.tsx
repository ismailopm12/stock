import { useEffect, useRef } from "react";
import { isEan13 } from "@/lib/scan-session";

export function Barcode({ value, height = 56, className }: { value: string; height?: number; className?: string }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    let alive = true;
    import("jsbarcode").then(({ default: JsBarcode }) => {
      if (!alive || !ref.current) return;
      try {
        JsBarcode(ref.current, value, { format: isEan13(value) ? "EAN13" : "CODE128", height, margin: 4, fontSize: 14, background: "#ffffff", lineColor: "#000000" });
      } catch { /* invalid value */ }
    });
    return () => { alive = false; };
  }, [value, height]);
  return <svg ref={ref} role="img" aria-label={`Barcode ${value}`} className={className} />;
}
