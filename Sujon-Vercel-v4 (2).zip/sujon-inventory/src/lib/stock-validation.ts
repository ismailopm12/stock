import { validateQuantity } from "@/lib/item-units";
export function validateStockQuantity(value: string, mode: "in" | "out" | "adjust", available?: number, unit = "pcs") {
  const quantity = validateQuantity(value, unit);
  if (!value.trim() || (mode !== "adjust" && quantity === 0)) {
    throw new Error("Enter a valid positive quantity.");
  }
  if (mode === "out" && (available === undefined || quantity > available)) {
    throw new Error("Quantity exceeds the selected batch stock.");
  }
  return quantity;
}