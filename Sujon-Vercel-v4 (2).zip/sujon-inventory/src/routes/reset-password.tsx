import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Eye, EyeOff, KeyRound, LoaderCircle, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Reset password — Sujon" }, { name: "description", content: "Set a new password." }, { property: "og:title", content: "Reset password — Sujon" }, { property: "og:description", content: "Set a new password for your Sujon account." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Reset,
});

function Reset() {
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState<boolean | null>(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const hasToken = /type=recovery|access_token|code=/.test(window.location.hash + window.location.search);
    const { data } = supabase.auth.onAuthStateChange((e, s) => { if (e === "PASSWORD_RECOVERY" || s) setReady(true); });
    supabase.auth.getSession().then(({ data: d }) => {
      if (d.session) setReady(true);
      else if (!hasToken) setReady(false);
      else setTimeout(() => setReady((r) => r ?? false), 4000);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (pw !== pw2) { setError("Passwords don't match."); return; }
    setBusy(true); setError("");
    try {
      const { error } = await supabase.auth.updateUser({ password: pw });
      if (error) throw error;
      toast.success("Password updated");
      await navigate({ to: "/dashboard" });
    } catch (err) {
      const m = err instanceof Error ? err.message : "";
      setError(/same|different/i.test(m) ? "New password must be different from the old one." : "This reset link may have expired. Return to sign in to request a new link.");
    } finally { setBusy(false); }
  }

  return (
    <div className="native-page mx-auto max-w-lg px-6 pt-14 pb-8">
      <div className="icon-pop grid h-14 w-14 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow"><KeyRound className="h-7 w-7" /></div>
      <h1 className="mt-5 text-2xl font-extrabold">Set new password</h1>
      <p className="mt-1 text-sm text-muted-foreground">Choose a strong password you haven't used before.</p>
      {ready === false ? (
        <div className="card-soft mt-6 p-5 text-sm">
          <p role="alert" className="font-semibold">This reset link is invalid or has expired.</p>
          <Button asChild className="mt-4 w-full rounded-2xl"><Link to="/auth" search={{ mode: "forgot" }}>Request a new link</Link></Button>
        </div>
      ) : (
        <form onSubmit={save} className="mt-6 space-y-4">
          {[{ id: "reset-password", label: "New password", v: pw, set: setPw }, { id: "reset-confirm", label: "Confirm password", v: pw2, set: setPw2 }].map((f) => (
            <div key={f.id} className="space-y-1.5">
              <label htmlFor={f.id} className="text-sm font-semibold">{f.label}</label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input id={f.id} autoComplete="new-password" disabled={busy || ready === null} type={show ? "text" : "password"} minLength={8} required value={f.v} onChange={(e) => f.set(e.target.value)} className="h-12 rounded-2xl bg-card pl-11 pr-12" />
                <Button type="button" variant="ghost" size="icon" aria-label={show ? "Hide password" : "Show password"} onClick={() => setShow(!show)} className="absolute right-1 top-1/2 h-10 w-10 -translate-y-1/2 rounded-xl text-muted-foreground">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          ))}
          {error && <p role="alert" className="rounded-xl bg-danger-soft p-3 text-sm text-destructive">{error}</p>}
          <Button disabled={busy || ready === null} className="h-12 w-full rounded-2xl shadow-glow">
            {(busy || ready === null) && <LoaderCircle className="h-4 w-4 animate-spin" />}
            {ready === null ? "Checking link…" : busy ? "Saving…" : "Save password"}
          </Button>
          <Button asChild variant="link" className="w-full"><Link to="/auth">Back to sign in</Link></Button>
        </form>
      )}
    </div>
  );
}
