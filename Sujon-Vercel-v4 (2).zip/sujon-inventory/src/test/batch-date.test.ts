import { describe, expect, it } from "vitest";
import { batchFromISO, batchToDate, isoFromBatch, isBatchDate, todayBatchNo } from "@/lib/batch-date";

describe("Date-based batch numbers", () => {
  it("writes a batch number as day/month/year", () => {
    expect(batchFromISO("2026-10-22")).toBe("22/10/2026");
    expect(isoFromBatch("22/10/2026")).toBe("2026-10-22");
  });

  it("defaults to today's date", () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    expect(todayBatchNo()).toBe(`${pad(now.getDate())}/${pad(now.getMonth() + 1)}/${now.getFullYear()}`);
  });

  it("accepts single digits and two-digit years", () => {
    expect(batchToDate("2/10/26")).toEqual(new Date(2026, 9, 2));
    expect(isoFromBatch("2/10/2026")).toBe("2026-10-02");
  });

  it("rejects impossible days and non-date batch codes", () => {
    expect(isBatchDate("31/02/2026")).toBe(false);
    expect(isBatchDate("31/04/2026")).toBe(false);
    expect(isBatchDate("B261022-123")).toBe(false);
    expect(isBatchDate("")).toBe(false);
    expect(batchFromISO("")).toBe("");
  });

  it("round-trips every month end", () => {
    for (let m = 0; m < 12; m++) {
      const iso = `2026-${String(m + 1).padStart(2, "0")}-01`;
      expect(isoFromBatch(batchFromISO(iso))).toBe(iso);
    }
  });
});
