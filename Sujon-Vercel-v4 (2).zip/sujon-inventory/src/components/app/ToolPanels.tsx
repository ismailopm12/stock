import { Link } from "@tanstack/react-router";
import { dayMonthYear } from "@/lib/display-date";
import { useMemo, useState, type ReactNode } from "react";
import { ChevronRight, Download, Search } from "lucide-react";
import { daysUntil, downloadCsv, money, stockStatus, totalQty, type Item, type Movement } from "@/lib/inventory";
import { StatusBadge } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export type ToolKey = "low" | "expiry" | "valuation" | "batches" | "categories" | "count" | "dead" | "movers";
export const toolTitles: Record<ToolKey, string> = {
  low: "Low stock alerts", expiry: "Expiry tracker", batches: "Batch explorer", valuation: "Stock valuation",
  categories: "Category summary", count: "Reorder planner", dead: "Dead stock finder", movers: "Top movers",
};

const DAY = 86400000;
const r3 = (n: number) => Math.round(n * 1000) / 1000;

/** Average daily stock-out per item over the last `days` days. */
export function dailyUsage(moves: Movement[], days = 30, now = Date.now()) {
  const since = now - days * DAY;
  const out = new Map<string, number>();
  moves.forEach((m) => { if (m.type === "out" && new Date(m.created_at).getTime() >= since) out.set(m.item_id, (out.get(m.item_id) ?? 0) + m.quantity); });
  return new Map([...out].map(([k, v]) => [k, v / days]));
}

function Chips<T extends string>({ value, options, onChange }: { value: T; options: [T, string][]; onChange: (v: T) => void }) {
  return <div className="flex gap-2 overflow-x-auto pb-1">{options.map(([k, l]) => (
    <Button key={k} size="sm" variant={value === k ? "default" : "outline"} aria-pressed={value === k} onClick={() => onChange(k)} className="shrink-0 rounded-full">{l}</Button>
  ))}</div>;
}

function Row({ to, title, sub, right, action }: { to: string; title: string; sub: string; right?: ReactNode; action?: ReactNode }) {
  return (
    <div className="native-list-item flex items-center gap-2 rounded-2xl bg-muted p-3">
      <Link to="/inventory/$id" params={{ id: to }} className="flex min-w-0 flex-1 items-center gap-3">
        <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{title}</p><p className="truncate text-xs text-muted-foreground">{sub}</p></div>
        {right}<ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
      </Link>
      {action}
    </div>
  );
}
const None = ({ text = "Nothing needs attention" }: { text?: string }) => <p className="py-8 text-center text-sm text-muted-foreground">{text}</p>;

export function ToolPanel({ tool, items, moves, onRestock }: { tool: ToolKey; items: Item[]; moves: Movement[]; onRestock: (id: string) => void }) {
  const [q, setQ] = useState("");
  const [expiryWin, setExpiryWin] = useState<"7" | "30" | "90" | "expired">("30");
  const [batchF, setBatchF] = useState<"active" | "empty" | "all">("active");
  const [deadDays, setDeadDays] = useState<"30" | "60" | "90">("60");
  const usage = useMemo(() => dailyUsage(moves), [moves]);
  const match = (s: string) => s.toLowerCase().includes(q.trim().toLowerCase());
  const list = items.filter((i) => match(`${i.name} ${i.sku ?? ""} ${i.barcode ?? ""} ${i.category ?? ""}`));
  const allBatches = list.flatMap((i) => i.batches.map((b) => ({ ...b, item: i })));

  let header: ReactNode = null;
  let body: ReactNode;
  let csv: (string | number | null)[][] = [];

  if (tool === "low") {
    const low = list.filter((i) => stockStatus(i) !== "in").sort((a, b) => totalQty(a) - totalQty(b));
    csv = [["Item", "On hand", "Min", "Unit", "Status"], ...low.map((i) => [i.name, totalQty(i), i.min_stock, i.unit, stockStatus(i)])];
    body = low.length ? low.map((i) => <Row key={i.id} to={i.id} title={i.name} sub={`${totalQty(i)} / min ${i.min_stock} ${i.unit}`} right={<StatusBadge s={stockStatus(i)} />}
      action={<Button size="sm" variant="stockIn" className="rounded-xl" onClick={() => onRestock(i.id)}>Restock</Button>} />) : <None />;
  } else if (tool === "expiry") {
    header = <Chips value={expiryWin} onChange={setExpiryWin} options={[["7", "7 days"], ["30", "30 days"], ["90", "90 days"], ["expired", "Expired"]]} />;
    const rows = allBatches.filter((b) => b.expiry_date && b.quantity > 0).map((b) => ({ ...b, d: daysUntil(b.expiry_date!) }))
      .filter((b) => expiryWin === "expired" ? b.d < 0 : b.d <= Number(expiryWin)).sort((a, b) => a.d - b.d);
    const atRisk = rows.reduce((s, b) => s + b.quantity * Number(b.item.price), 0);
    csv = [["Item", "Batch", "Expiry", "Days left", "Qty", "Unit", "Value"], ...rows.map((b) => [b.item.name, b.batch_no, b.expiry_date, b.d, b.quantity, b.item.unit, r3(b.quantity * Number(b.item.price))])];
    body = rows.length ? <>
      <div className="rounded-2xl bg-danger-soft p-3 text-sm"><b className="text-destructive">{money(atRisk)}</b> of stock at risk in {rows.length} batches</div>
      {rows.map((b) => <Row key={b.id} to={b.item.id} title={b.item.name} sub={`Batch ${b.batch_no} · ${b.quantity} ${b.item.unit} · ${dayMonthYear(b.expiry_date)}`}
        right={<span className={cn("text-xs font-bold", b.d < 0 ? "text-destructive" : b.d <= 7 ? "text-destructive" : "text-warning")}>{b.d < 0 ? `${-b.d}d ago` : `${b.d}d`}</span>} />)}
    </> : <None />;
  } else if (tool === "batches") {
    header = <Chips value={batchF} onChange={setBatchF} options={[["active", "With stock"], ["empty", "Empty"], ["all", "All"]]} />;
    const rows = allBatches.filter((b) => batchF === "all" || (batchF === "active" ? b.quantity > 0 : b.quantity <= 0))
      .sort((a, b) => (a.expiry_date ?? "9999").localeCompare(b.expiry_date ?? "9999"));
    csv = [["Batch", "Item", "Qty", "Unit", "Expiry", "Created"], ...rows.map((b) => [b.batch_no, b.item.name, b.quantity, b.item.unit, b.expiry_date, b.created_at.slice(0, 10)])];
    body = rows.length ? rows.map((b) => <Row key={b.id} to={b.item.id} title={b.batch_no} sub={`${b.item.name}${b.expiry_date ? ` · exp ${dayMonthYear(b.expiry_date)}` : ""}`} right={<span className="text-sm font-bold tabular-nums">{b.quantity} <span className="text-xs font-normal text-muted-foreground">{b.item.unit}</span></span>} />) : <None text="No batches" />;
  } else if (tool === "valuation") {
    const rows = [...list].map((i) => ({ i, v: totalQty(i) * Number(i.price) })).sort((a, b) => b.v - a.v);
    const total = rows.reduce((s, r) => s + r.v, 0);
    csv = [["Item", "Qty", "Unit", "Price", "Value", "Share %"], ...rows.map(({ i, v }) => [i.name, totalQty(i), i.unit, Number(i.price), r3(v), total ? r3((v / total) * 100) : 0])];
    body = <>
      <div className="rounded-2xl bg-gradient-primary p-4 text-primary-foreground"><p className="text-xs opacity-85">Total value</p><p className="text-2xl font-extrabold">{money(total)}</p></div>
      {rows.map(({ i, v }) => (
        <div key={i.id}><Row to={i.id} title={i.name} sub={`${totalQty(i)} ${i.unit} × ${money(Number(i.price))}`} right={<span className="text-sm font-bold">{money(v)}</span>} />
          <div className="mx-3 -mt-1 h-1 overflow-hidden rounded-full bg-border"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${total ? (v / total) * 100 : 0}%` }} /></div></div>
      ))}
    </>;
  } else if (tool === "categories") {
    const cats = new Map<string, { items: number; low: number; value: number }>();
    list.forEach((i) => { const c = cats.get(i.category || "Uncategorized") ?? { items: 0, low: 0, value: 0 }; c.items++; if (stockStatus(i) !== "in") c.low++; c.value += totalQty(i) * Number(i.price); cats.set(i.category || "Uncategorized", c); });
    const rows = [...cats].sort((a, b) => b[1].value - a[1].value);
    csv = [["Category", "Items", "Low/out", "Value"], ...rows.map(([c, v]) => [c, v.items, v.low, r3(v.value)])];
    body = rows.length ? rows.map(([c, v]) => (
      <div key={c} className="flex items-center justify-between gap-3 rounded-2xl bg-muted p-3 text-sm">
        <div className="min-w-0"><p className="truncate font-semibold">{c}</p><p className="text-xs text-muted-foreground">{v.items} items{v.low ? ` · ${v.low} low/out` : ""}</p></div><b>{money(v.value)}</b>
      </div>)) : <None />;
  } else if (tool === "count") {
    const rows = list.map((i) => {
      const onHand = totalQty(i); const u = usage.get(i.id) ?? 0;
      const cover = u > 0 ? onHand / u : Infinity;
      const target = Math.max(i.min_stock * 2, u * 30);
      const order = r3(Math.max(target - onHand, 0));
      return { i, onHand, u, cover, order };
    }).filter((r) => r.order > 0 && (stockStatus(r.i) !== "in" || r.cover <= 14)).sort((a, b) => a.cover - b.cover);
    csv = [["Item", "On hand", "Unit", "Avg daily out (30d)", "Days of cover", "Suggested order"], ...rows.map((r) => [r.i.name, r.onHand, r.i.unit, r3(r.u), Number.isFinite(r.cover) ? Math.floor(r.cover) : "", r.order])];
    body = <>
      <p className="text-xs text-muted-foreground">Suggests enough to cover 30 days of sales (or twice the minimum), based on stock out over the last 30 days.</p>
      {rows.length ? rows.map((r) => <Row key={r.i.id} to={r.i.id} title={r.i.name}
        sub={`On hand ${r.onHand} ${r.i.unit}${Number.isFinite(r.cover) ? ` · ~${Math.floor(r.cover)} days left` : ""}`}
        right={<span className="shrink-0 rounded-full bg-success-soft px-2 py-0.5 text-xs font-bold text-success">Order {r.order}</span>}
        action={<Button size="sm" variant="outline" className="rounded-xl" onClick={() => onRestock(r.i.id)}>Receive</Button>} />) : <None />}
    </>;
  } else if (tool === "dead") {
    header = <Chips value={deadDays} onChange={setDeadDays} options={[["30", "30 days"], ["60", "60 days"], ["90", "90 days"]]} />;
    const since = Date.now() - Number(deadDays) * DAY;
    const lastOut = new Map<string, number>();
    moves.forEach((m) => { if (m.type === "out") lastOut.set(m.item_id, Math.max(lastOut.get(m.item_id) ?? 0, new Date(m.created_at).getTime())); });
    const rows = list.filter((i) => totalQty(i) > 0 && (lastOut.get(i.id) ?? 0) < since).map((i) => ({ i, last: lastOut.get(i.id), v: totalQty(i) * Number(i.price) })).sort((a, b) => b.v - a.v);
    csv = [["Item", "On hand", "Unit", "Value", "Last stock out"], ...rows.map((r) => [r.i.name, totalQty(r.i), r.i.unit, r3(r.v), r.last ? new Date(r.last).toISOString().slice(0, 10) : "Never"])];
    body = rows.length ? rows.map((r) => <Row key={r.i.id} to={r.i.id} title={r.i.name} sub={`${totalQty(r.i)} ${r.i.unit} · last out ${r.last ? dayMonthYear(r.last) : "never"}`} right={<span className="text-sm font-bold">{money(r.v)}</span>} />) : <None text="All stock is moving" />;
  } else {
    const since = Date.now() - 30 * DAY;
    const agg = new Map<string, { in: number; out: number }>();
    moves.forEach((m) => { if (m.type === "adjust" || new Date(m.created_at).getTime() < since) return; const a = agg.get(m.item_id) ?? { in: 0, out: 0 }; a[m.type] += m.quantity; agg.set(m.item_id, a); });
    const rows = list.map((i) => ({ i, a: agg.get(i.id) ?? { in: 0, out: 0 } })).filter((r) => r.a.out > 0).sort((a, b) => b.a.out - a.a.out);
    const max = rows[0]?.a.out ?? 1;
    csv = [["Item", "Unit", "Stock in (30d)", "Stock out (30d)"], ...rows.map((r) => [r.i.name, r.i.unit, r3(r.a.in), r3(r.a.out)])];
    body = rows.length ? rows.map((r, n) => (
      <div key={r.i.id}><Row to={r.i.id} title={`#${n + 1} ${r.i.name}`} sub={`In ${r3(r.a.in)} · Out ${r3(r.a.out)} ${r.i.unit} (30 days)`} right={<span className="text-sm font-bold text-destructive">−{r3(r.a.out)}</span>} />
        <div className="mx-3 -mt-1 h-1 overflow-hidden rounded-full bg-border"><div className="h-full rounded-full bg-destructive transition-all" style={{ width: `${(r.a.out / max) * 100}%` }} /></div></div>
    )) : <None text="No stock out in the last 30 days" />;
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input aria-label="Search in tool" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search items" className="h-10 rounded-xl bg-card pl-9" /></div>
        <Button variant="outline" className="h-10 rounded-xl" disabled={csv.length < 2} onClick={() => downloadCsv(`${tool}-${new Date().toISOString().slice(0, 10)}.csv`, csv)}><Download className="h-4 w-4" />CSV</Button>
      </div>
      {header}
      {body}
    </div>
  );
}
