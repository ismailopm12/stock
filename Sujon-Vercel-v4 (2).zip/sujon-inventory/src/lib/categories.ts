import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
export const categoriesQuery = queryOptions({ queryKey: ["categories"], queryFn: async () => {
  const { data, error } = await supabase.from("categories").select("id,name").order("name");
  if (error) throw error;
  return data ?? [];
} });
export function categoryName(name: string) {
  const clean = name.trim();
  if (!clean) throw new Error("Enter a category name.");
  return clean;
}
export async function createCategory(name: string) {
  const clean = categoryName(name);
  const { error } = await supabase.from("categories").insert({ name: clean });
  if (error && error.code !== "23505") throw new Error(error.message);
  return clean;
}