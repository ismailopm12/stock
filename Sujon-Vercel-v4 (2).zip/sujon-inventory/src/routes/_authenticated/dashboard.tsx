import { Button } from "@/components/ui/button";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Activity, AlertTriangle, ArrowDownLeft, ArrowUpRight, Box, DollarSign, PackageX, Plus, SlidersHorizontal, ChevronRight, ShieldCheck } from "lucide-react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { StockTrend, useChartMotion } from "@/components/app/StockTrend";
import { CountUp } from "@/components/app/CountUp";
import { itemsQuery, movementsQuery, money, profileQuery, stockStatus, totalQty } from "@/lib/inventory";
import { StockSheet } from "@/components/app/StockSheet";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Sujon" }, { name: "description", content: "Stock overview." }, { property: "og:title", content: "Dashboard — Sujon" }, { property: "og:description", content: "Your stock overview and recent activity." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(itemsQuery),
    context.queryClient.ensureQueryData(movementsQuery()),
    context.queryClient.ensureQueryData(profileQuery),
  ]),
  component: Dashboard,
});

function greet() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

function Dashboard() {
  const { data: items } = useSuspenseQuery(itemsQuery);
  const { data: moves } = useSuspenseQuery(movementsQuery());
  const { data: profile } = useSuspenseQuery(profileQuery);
  const [sheet, setSheet] = useState<null | "in" | "out">(null);

  const value = items.reduce((s, i) => s + totalQty(i) * Number(i.price), 0);
  const units = items.reduce((s, i) => s + totalQty(i), 0);
  const out = items.filter((i) => stockStatus(i) === "out").length;
  const low = items.filter((i) => stockStatus(i) === "low").length;

  const animate = useChartMotion();
  const health = [
    { name: "In stock", value: items.length - low - out, color: "var(--success)", tone: "bg-success", status: "in" },
    { name: "Low stock", value: low, color: "var(--warning)", tone: "bg-warning", status: "low" },
    { name: "Out of stock", value: out, color: "var(--destructive)", tone: "bg-destructive", status: "out" },
  ];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todays = moves.filter((m) => new Date(m.created_at) >= today);
  const todayIn = todays.filter((m) => m.type === "in").length;
  const todayOut = todays.filter((m) => m.type === "out").length;
  const stats = [
    { label: "Total Stock Value", num: value, fmt: (n: number) => money(n), icon: DollarSign, hero: true },
    { label: "Total Units", num: units, fmt: (n: number) => Math.round(n).toLocaleString(), icon: Box, tone: "bg-mint-soft text-mint" },
    { label: "Out of Stock", num: out, fmt: (n: number) => String(Math.round(n)).padStart(2, "0"), icon: PackageX, tone: "bg-danger-soft text-destructive" },
    { label: "Low Stock", num: low, fmt: (n: number) => String(Math.round(n)).padStart(2, "0"), icon: AlertTriangle, tone: "bg-warning-soft text-warning" },
  ];

  return (
    <div>
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 pt-6 pb-4">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary-soft text-lg font-bold text-accent-foreground">
            {(profile?.full_name || "U").charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase text-muted-foreground">{greet()}</p>
            <p className="truncate text-xl font-extrabold">{profile?.full_name || "there"} 👋</p>
          </div>
        </div>
        <Link to="/inventory/new" aria-label="Add item" title="Add item" className="tap grid h-11 w-11 place-items-center rounded-full bg-card shadow-soft"><Plus className="h-5 w-5" /></Link>
      </header>

      <div className="grid grid-cols-2 gap-3 px-5">
        {stats.map((s) => (
          <div key={s.label} className={s.hero ? "hero-shine rounded-3xl p-4 text-primary-foreground shadow-glow" : `card-soft p-4 ${s.tone?.split(" ")[0] ?? ""}`}>
            <div className={`grid h-10 w-10 place-items-center rounded-full ${s.hero ? "bg-card text-primary" : s.tone}`}><s.icon className="animated-icon h-5 w-5" /></div>
            <p className="item-number mt-4 break-all text-xl font-extrabold tabular-nums"><CountUp value={s.num} format={s.fmt} /></p>
            <p className={`text-xs ${s.hero ? "opacity-85" : "text-muted-foreground"}`}>{s.label}</p>
          </div>
        ))}
      </div>

      <Link to="/history" className="card-soft tap mx-5 mt-3 flex items-center gap-3 p-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary"><Activity className="animated-icon h-5 w-5" /></div>
        <div className="min-w-0 flex-1"><p className="text-sm font-semibold">Today</p><p className="text-xs text-muted-foreground">{todays.length} movements recorded</p></div>
        <span className="rounded-full bg-success-soft px-2 py-1 text-xs font-bold text-success">+{todayIn}</span>
        <span className="rounded-full bg-danger-soft px-2 py-1 text-xs font-bold text-destructive">−{todayOut}</span>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <div className="mt-4 grid grid-cols-2 gap-3 px-5">
        <Button variant="ghost" onClick={() => setSheet("in")} disabled={!items.length} className="tap flex h-14 items-center justify-center gap-2 rounded-2xl bg-success-soft font-semibold text-success disabled:opacity-50">
          <ArrowDownLeft className="h-5 w-5" /> Stock In
        </Button>
        <Button variant="ghost" onClick={() => setSheet("out")} disabled={!items.length} className="tap flex h-14 items-center justify-center gap-2 rounded-2xl bg-danger-soft font-semibold text-destructive disabled:opacity-50">
          <ArrowUpRight className="h-5 w-5" /> Stock Out
        </Button>
      </div>

      <StockTrend moves={moves} />
      <section className="mx-5 mt-6 border-t border-border pt-5" aria-label="Inventory health">
        <div className="flex items-center justify-between"><h2 className="flex items-center gap-2 font-bold"><ShieldCheck className="animated-icon h-5 w-5 text-primary" />Inventory health</h2><Button asChild size="sm" variant="link"><Link to="/inventory">View items<ChevronRight /></Link></Button></div>
        <div className="mt-3 grid grid-cols-[128px_minmax(0,1fr)] items-center gap-4">
          <div className="relative h-36">
            {items.length ? <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={health} dataKey="value" nameKey="name" innerRadius={44} outerRadius={60} paddingAngle={4} stroke="var(--background)" isAnimationActive={animate} animationDuration={900}>{health.map((entry) => <Cell key={entry.name} fill={entry.color} />)}</Pie><Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8 }} /></PieChart></ResponsiveContainer> : <div className="mx-auto mt-3 h-28 w-28 rounded-full border-8 border-muted" />}
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center"><span className="item-number text-2xl font-extrabold">{items.length}</span><span className="text-[10px] text-muted-foreground">products</span></div>
          </div>
          <div className="min-w-0 space-y-3">{health.map((entry) => <Link key={entry.name} to="/inventory" search={{ status: entry.status as "in" | "low" | "out" }} className="native-control flex items-center gap-2 text-xs"><span className={`h-2 w-2 shrink-0 rounded-full ${entry.tone}`} /><span className="flex-1">{entry.name}</span><strong className="text-base tabular-nums">{entry.value}</strong><ChevronRight className="h-3 w-3 text-muted-foreground" /></Link>)}</div>
        </div>
        {(low + out) > 0 && <div className="mt-2 flex items-center gap-3 rounded-xl bg-warning-soft p-3 text-warning"><AlertTriangle className="animated-icon h-5 w-5 shrink-0" /><p className="flex-1 text-xs font-semibold">{low + out} products need restocking</p><Button asChild variant="ghost" size="sm"><Link to="/inventory" search={{ status: out ? "out" : "low" }}>Review<ChevronRight /></Link></Button></div>}
      </section>

      <section className="mt-5 px-5">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-bold">Recent activity</h2>
          <Link to="/history" className="text-sm font-semibold text-primary">See all</Link>
        </div>
        <div className="space-y-2">
          {moves.slice(0, 5).map((m) => (
            <Link to="/inventory/$id" params={{ id: m.item_id }} key={m.id} className="card-soft tap flex items-center gap-3 p-3">
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${m.type === "in" ? "bg-success-soft text-success" : m.type === "out" ? "bg-danger-soft text-destructive" : "bg-primary-soft text-accent-foreground"}`}>
                {m.type === "in" ? <ArrowDownLeft className="h-4 w-4" /> : m.type === "out" ? <ArrowUpRight className="h-4 w-4" /> : <SlidersHorizontal className="h-4 w-4" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{m.items?.name}</p>
                <p className="truncate text-xs text-muted-foreground">Batch {m.batch_no}</p>
              </div>
              <p className="shrink-0 text-sm font-bold">{m.type === "out" ? "−" : m.type === "in" ? "+" : "="}{m.quantity}</p>
            </Link>
          ))}
          {!moves.length && <p className="card-soft p-5 text-center text-sm text-muted-foreground">No movements yet. Add an item, then record Stock In.</p>}
        </div>
      </section>

      <StockSheet open={!!sheet} onOpenChange={(o) => !o && setSheet(null)} items={items} defaultMode={sheet ?? "in"} />
    </div>
  );
}
