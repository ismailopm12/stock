import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import { recoverChunkLoad } from "./lib/chunk-recovery";
import { PageLoadError } from "./components/app/PageLoadError";

// After a deploy or route rename, an open tab can hold a stale route tree and
// fail to lazy-import a chunk that no longer exists. Reload once to recover
// instead of blanking the screen.
if (typeof window !== "undefined") {
  window.addEventListener("unhandledrejection", (event) => {
    if (recoverChunkLoad(event.reason)) event.preventDefault();
  });
  window.addEventListener("vite:preloadError", (event) => {
    if (recoverChunkLoad((event as Event & { payload?: unknown }).payload)) event.preventDefault();
  });
}

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
    defaultErrorComponent: PageLoadError,
    defaultOnCatch: (error) => { recoverChunkLoad(error); },
  });

  return router;
};
