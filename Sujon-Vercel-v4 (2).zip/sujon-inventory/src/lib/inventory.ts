import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { todayBatchNo } from "@/lib/batch-date";

export type Batch = { id: string; item_id: string; batch_no: string; quantity: number; expiry_date: string | null; created_at: string };
export type Item = {
  id: string; name: string; sku: string | null; category: string | null; unit: string;
  price: number; min_stock: number; created_at: string; image_url: string | null; barcode: string | null; batches: Batch[];
};
export type Movement = {
  id: string; item_id: string; batch_no: string | null; type: "in" | "out" | "adjust";
  quantity: number; note: string | null; created_at: string; items: { name: string; unit: string } | null;
};

export const totalQty = (i: Item) => i.batches.reduce((s, b) => s + b.quantity, 0);
export type StockStatus = "in" | "low" | "out";
export function stockStatus(i: Item): StockStatus {
  const q = totalQty(i);
  if (q <= 0) return "out";
  if (q <= i.min_stock) return "low";
  return "in";
}
export const money = (n: number) =>
  new Intl.NumberFormat(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

export const itemsQuery = queryOptions({
  queryKey: ["items"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("items")
      .select("*, batches(*)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []).map((item) => ({ ...item, min_stock: Number(item.min_stock_decimal), batches: item.batches.map((batch) => ({ ...batch, quantity: Number(batch.quantity_decimal) })) })) as unknown as Item[];
  },
});

export const movementsQuery = (limit?: number) =>
  queryOptions({
    queryKey: ["movements", limit],
    queryFn: async () => {
      const rows: Movement[] = [];
      const pageSize = 500;
      for (let offset = 0; ; offset += pageSize) {
        const count = limit ? Math.min(pageSize, limit - offset) : pageSize;
        if (count <= 0) break;
        const { data, error } = await supabase.from("movements")
          .select("*, items(name, unit)")
          .order("created_at", { ascending: false }).order("id", { ascending: false })
          .range(offset, offset + count - 1);
        if (error) throw error;
        rows.push(...((data ?? []).map((movement) => ({ ...movement, quantity: Number(movement.quantity_decimal) })) as unknown as Movement[]));
        if (!data || data.length < count) break;
      }
      return rows;
    },
  });

export const profileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return null;
    const { data } = await supabase.from("profiles").select("*").eq("id", u.user.id).maybeSingle();
    return { email: u.user.email ?? "", full_name: data?.full_name ?? "", company: data?.company ?? "", id: u.user.id };
  },
});

export async function recordMovement(p: {
  item_id: string; batch_no: string; type: "in" | "out" | "adjust"; qty: number; note?: string; expiry?: string | null;
}) {
  const { error } = await supabase.rpc("record_movement", {
    _item_id: p.item_id, _batch_no: p.batch_no, _type: p.type, _amount: p.qty,
    ...(p.note ? { _note: p.note } : {}), ...(p.expiry ? { _expiry: p.expiry } : {}),
  });
  if (error) throw error;
}

export function daysUntil(date: string) {
  return Math.ceil((new Date(date).getTime() - Date.now()) / 86400000);
}

export function downloadCsv(name: string, rows: (string | number | null)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

/** Batches are identified by day, e.g. "22/10/2026". */
export function genBatchNo() {
  return todayBatchNo();
}
