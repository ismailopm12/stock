import type { Item, Movement } from "@/lib/inventory";

export type ReportFilters = { start: string; end: string; search: string; itemId: string };
export type ItemReportRow = { item: Item; available: number; stockIn: number; stockOut: number };

export function localDate(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function recentDateRange(days: number, now = new Date()) {
  const first = new Date(now);
  first.setDate(first.getDate() - days + 1);
  return { start: localDate(first), end: localDate(now) };
}

export function reportBounds(start: string, end: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start > end) return null;
  const first = new Date(`${start}T00:00:00`);
  const last = new Date(`${end}T00:00:00`);
  if (!Number.isFinite(first.getTime()) || !Number.isFinite(last.getTime())) return null;
  last.setDate(last.getDate() + 1);
  return { start: first.getTime(), endExclusive: last.getTime() };
}

export function buildItemReport(items: Item[], movements: Movement[], filters: ReportFilters) {
  const bounds = reportBounds(filters.start, filters.end);
  const search = filters.search.trim().toLowerCase();
  const selected = items.filter((i) => (!filters.itemId || i.id === filters.itemId) &&
    `${i.name} ${i.sku ?? ""} ${i.category ?? ""}`.toLowerCase().includes(search));
  const totals = new Map<string, { stockIn: number; stockOut: number }>();
  if (bounds) for (const movement of movements) {
    const time = new Date(movement.created_at).getTime();
    if (time < bounds.start || time >= bounds.endExclusive) continue;
    const total = totals.get(movement.item_id) ?? { stockIn: 0, stockOut: 0 };
    if (movement.type === "in") total.stockIn += movement.quantity;
    if (movement.type === "out") total.stockOut += movement.quantity;
    totals.set(movement.item_id, total);
  }
  return selected.map((item): ItemReportRow => ({
    item, available: item.batches.reduce((sum, batch) => sum + batch.quantity, 0),
    ...(totals.get(item.id) ?? { stockIn: 0, stockOut: 0 }),
  })).sort((a, b) => a.item.name.localeCompare(b.item.name));
}

export function itemReportCsv(rows: ItemReportRow[], start: string, end: string) {
  return [
    ["Item", "SKU", "Category", "Unit", "Available now", "Stock in", "Stock out", "From", "To"],
    ...rows.map((row) => [row.item.name, row.item.sku, row.item.category, row.item.unit,
      row.available, row.stockIn, row.stockOut, start, end]),
  ];
}