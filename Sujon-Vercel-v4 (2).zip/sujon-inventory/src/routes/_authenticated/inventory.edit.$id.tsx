import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { itemsQuery } from "@/lib/inventory";
import type { ItemDraft } from "@/lib/create-item";
import { deleteItemImage, uploadItemImage } from "@/lib/item-image";
import { ItemForm, type ItemImageSelection } from "@/components/app/ItemForm";
import { Button } from "@/components/ui/button";
import { normalizeUnit, parseQuantity } from "@/lib/item-units";

export const Route = createFileRoute("/_authenticated/inventory/edit/$id")({
  head: () => ({ meta: [
    { title: "Edit item — Sujon" }, { name: "description", content: "Edit an inventory item's details and photo." },
    { property: "og:title", content: "Edit item — Sujon" }, { property: "og:description", content: "Edit an inventory item's details and photo." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(itemsQuery),
  component: EditItem,
});

function EditItem() {
  const { id } = Route.useParams();
  const { data: items } = useSuspenseQuery(itemsQuery);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const item = items.find((i) => i.id === id);

  if (!item) {
    return (
      <div className="px-5 py-10 text-center">
        <Package className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
        <h1 className="text-lg font-bold">Item not found</h1>
        <Button asChild variant="link"><Link to="/inventory">Back to inventory</Link></Button>
      </div>
    );
  }

  const initial: ItemDraft = {
    name: item.name, sku: item.sku ?? "", category: item.category ?? "", unit: item.unit,
    price: String(item.price), min_stock: String(item.min_stock), qty: "", batch: "", expiry: "",
  };

  const oldImagePath = item.image_url;
  async function save(f: ItemDraft, image: ItemImageSelection) {
    let image_url = oldImagePath;
    if (image.file) {
      image_url = await uploadItemImage(id, image.file);
    } else if (image.remove) {
      image_url = null;
    }
    const { error } = await supabase.from("items").update({
      name: f.name.trim(), sku: f.sku.trim() || null, category: f.category.trim() || null,
      unit: normalizeUnit(f.unit), price: Number(f.price), min_stock: Math.trunc(parseQuantity(f.min_stock, f.unit)), min_stock_decimal: parseQuantity(f.min_stock, f.unit), image_url,
    }).eq("id", id);
    if (error) throw new Error(error.message);
    if (oldImagePath && oldImagePath !== image_url) {
      try { await deleteItemImage(oldImagePath); }
      catch { toast.warning("Item saved; the previous photo could not be removed."); }
    }
    await qc.invalidateQueries({ queryKey: itemsQuery.queryKey });
    toast.success("Item updated");
    await navigate({ to: "/inventory/$id", params: { id } });
  }

  return <ItemForm mode="edit" initial={initial} initialImagePath={item.image_url} backTo="/inventory" onSubmit={save} />;
}
