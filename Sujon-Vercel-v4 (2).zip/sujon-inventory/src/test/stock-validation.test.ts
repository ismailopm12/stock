import { describe, expect, it } from "vitest";
import { validateStockQuantity } from "@/lib/stock-validation";

describe("Stock movement validation", () => {
  it("rejects fractions instead of silently rounding them", () => {
    expect(() => validateStockQuantity("1.5", "in")).toThrow();
  });
  it("does not permit stock-out without an available batch", () => {
    expect(() => validateStockQuantity("1", "out")).toThrow();
  });
  it("rejects removing more units than the batch contains", () => {
    expect(() => validateStockQuantity("6", "out", 5)).toThrow();
    expect(validateStockQuantity("5", "out", 5)).toBe(5);
  });
  it("permits adjusting a batch to zero", () => {
    expect(validateStockQuantity("0", "adjust", 5)).toBe(0);
    expect(() => validateStockQuantity("0", "in")).toThrow();
  });
});