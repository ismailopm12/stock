import { describe, expect, it } from "vitest";
import { isEan13, planAudit, planOut } from "@/lib/scan-session";

const b = (batch_no: string, quantity: number, expiry_date: string | null, created_at: string) => ({ batch_no, quantity, expiry_date, created_at });
const batches = [b("B2", 5, null, "2026-02-01"), b("B1", 3, "2026-03-01", "2026-01-01")];

describe("scan session planning", () => {
  it("stock out takes the earliest-expiring batch first and splits", () => {
    expect(planOut(batches, 4)).toEqual([{ batch_no: "B1", type: "out", qty: 3 }, { batch_no: "B2", type: "out", qty: 1 }]);
  });
  it("stock out rejects more than available", () => {
    expect(() => planOut(batches, 9)).toThrow(/short by 1/);
  });
  it("audit shortage reduces batches FEFO", () => {
    expect(planAudit(batches, 6, "NEW")).toEqual([{ batch_no: "B1", type: "adjust", qty: 1 }]);
  });
  it("audit surplus goes to newest batch", () => {
    expect(planAudit(batches, 10, "NEW")).toEqual([{ batch_no: "B2", type: "adjust", qty: 7 }]);
  });
  it("audit with no batches creates a new batch", () => {
    expect(planAudit([], 2.5, "NEW")).toEqual([{ batch_no: "NEW", type: "in", qty: 2.5 }]);
  });
  it("audit matching count changes nothing", () => {
    expect(planAudit(batches, 8, "NEW")).toEqual([]);
  });
  it("validates EAN-13 check digits", () => {
    expect(isEan13("4006381333931")).toBe(true);
    expect(isEan13("4006381333932")).toBe(false);
  });
});
