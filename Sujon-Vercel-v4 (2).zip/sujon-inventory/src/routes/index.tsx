import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Boxes, Layers, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sujon — Precision inventory for growing businesses" },
      { name: "description", content: "Track stock in and out with batch control, expiry tracking and reports — on any device." },
      { property: "og:title", content: "Sujon — Precision inventory" },
      { property: "og:description", content: "Stock in/out, batch control, history and reports in a fast mobile app." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="native-page mx-auto flex min-h-dvh max-w-lg flex-col px-6 pt-10 pb-8">
      <div className="flex items-center gap-2">
        <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow">
          <Boxes className="animated-icon h-5 w-5" />
        </div>
        <span className="text-lg font-extrabold">Sujon</span>
      </div>
      <h1 className="mt-12 text-4xl font-extrabold leading-tight">
        Sujon
      </h1>
      <p className="mt-2 text-muted-foreground">Your inventory workspace</p>
      <div aria-hidden="true" className="mt-8 grid grid-cols-3 gap-4">
        <div className="native-list-item grid aspect-square place-items-center rounded-3xl bg-primary-soft text-accent-foreground"><Boxes className="animated-icon h-10 w-10" /></div>
        <div className="native-list-item grid aspect-square place-items-center rounded-3xl bg-mint-soft text-mint"><Layers className="animated-icon h-10 w-10" /></div>
        <div className="native-list-item grid aspect-square place-items-center rounded-3xl bg-warning-soft text-warning"><ShieldCheck className="animated-icon h-10 w-10" /></div>
      </div>
      <div className="mt-auto space-y-3 pt-10">
        <Link to="/auth" search={{ mode: "register" }} className="tap flex h-14 items-center justify-center gap-2 rounded-2xl bg-gradient-primary font-semibold text-primary-foreground shadow-glow">
          Get started <ArrowRight className="h-4 w-4" />
        </Link>
        <Link to="/auth" search={{ mode: "login" }} className="tap flex h-14 items-center justify-center rounded-2xl bg-card font-semibold shadow-soft">
          I already have an account
        </Link>
        <p className="pt-2 text-center text-xs font-medium text-muted-foreground">Development by Sujon</p>
      </div>
    </div>
  );
}
