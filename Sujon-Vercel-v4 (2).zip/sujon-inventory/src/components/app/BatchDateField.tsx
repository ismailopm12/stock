import { CalendarDays } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { batchFromISO, batchToDate, formatBatchDate, isBatchDate, isoFromBatch, todayBatchNo } from "@/lib/batch-date";
import { cn } from "@/lib/utils";

/**
 * Batch picker: every batch is a day, always shown and stored as
 * day/month/year (e.g. "22/10/2026"). The text field can be typed into, and
 * the calendar button opens the device's native date picker.
 */
export function BatchDateField({
  id, value, onChange, disabled, label = "Batch date", className,
}: {
  id: string; value: string; onChange: (v: string) => void; disabled?: boolean;
  label?: string; className?: string;
}) {
  const dated = isBatchDate(value);
  const note = !value.trim() ? "Pick the day — saved as day/month/year"
    : dated ? "Batch day for this stock"
    : "Not a date yet — tap the calendar to start a dated batch";

  return (
    <div className={cn("min-w-0 space-y-1.5", className)}>
      <Label htmlFor={id} className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
        <CalendarDays className="h-3.5 w-3.5" />{label}
      </Label>
      <div className="flex items-center gap-2">
        <Input
          id={id}
          disabled={disabled}
          value={value}
          placeholder={todayBatchNo()}
          inputMode="numeric"
          autoComplete="off"
          aria-describedby={`${id}-hint`}
          onChange={(e) => onChange(e.target.value)}
          onBlur={() => { const d = batchToDate(value); if (d) onChange(formatBatchDate(d)); }}
          className="h-11 min-w-0 flex-1 rounded-xl text-base font-semibold tabular-nums"
        />
        <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary-soft">
          <CalendarDays className="pointer-events-none h-4 w-4 text-accent-foreground" />
          <input
            type="date"
            disabled={disabled}
            value={isoFromBatch(value)}
            onChange={(e) => onChange(batchFromISO(e.target.value))}
            aria-label={`Pick ${label.toLowerCase()}`}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </span>
      </div>
      <p id={`${id}-hint`} className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
        <span className="min-w-0 truncate">
          {dated ? <>Batch <span className="font-bold text-foreground tabular-nums">{value}</span></> : note}
        </span>
        {!dated && (
          <Button type="button" variant="outline" size="sm" disabled={disabled}
            className="h-7 shrink-0 rounded-lg px-2 text-[11px] font-semibold"
            onClick={() => onChange(todayBatchNo())}>Today</Button>
        )}
      </p>
    </div>
  );
}
