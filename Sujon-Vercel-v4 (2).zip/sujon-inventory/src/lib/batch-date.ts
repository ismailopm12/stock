// Browser-safe helpers for date-based batch numbers: every batch is identified
// by a day, written day/month/year, e.g. "22/10/2026".
const pad = (n: number) => String(n).padStart(2, "0");

/** "22/10/2026" for the given day (local calendar). */
export function formatBatchDate(d: Date): string {
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

/** Today's batch number, e.g. "22/10/2026". */
export function todayBatchNo(): string {
  return formatBatchDate(new Date());
}

/** Parses "22/10/2026" (also "2/10/26") into a local Date, or null if not a real day. */
export function batchToDate(value: string): Date | null {
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(value.trim());
  if (!m) return null;
  const dd = m[1] ?? "", mm = m[2] ?? "", yy = m[3] ?? "";
  const day = Number(dd);
  const month = Number(mm);
  let year = Number(yy);
  if (yy.length === 2) year += year < 70 ? 2000 : 1900;
  if (!Number.isInteger(day) || !Number.isInteger(month) || month < 1 || month > 12) return null;
  const d = new Date(year, month - 1, day);
  if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
  return d;
}

export function isBatchDate(value: string): boolean {
  return batchToDate(value) !== null;
}

/** Native date-input value ("2026-10-22") -> batch number ("22/10/2026"). */
export function batchFromISO(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!m) return "";
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? "" : formatBatchDate(d);
}

/** Batch number ("22/10/2026") -> native date-input value ("2026-10-22"), "" when not a date. */
export function isoFromBatch(value: string): string {
  const d = batchToDate(value);
  if (!d) return "";
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
