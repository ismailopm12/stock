// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  // On Vercel, emit Vercel's serverless output instead of the Cloudflare default.
  // Inside the Lovable build environment the sandbox forces its own target, so
  // this only takes effect when the build runs on Vercel.
  ...(process.env["VERCEL"] ? { nitro: { preset: "vercel" } } : {}),
  // Pre-bundle lazily imported deps at startup so Vite never re-optimizes mid-session
  // (a late re-optimization loads a second React copy and blanks the page).
  vite: {
    optimizeDeps: { include: ["jsbarcode", "@zxing/browser", "@zxing/library", "@radix-ui/react-checkbox"] },
  },
});
