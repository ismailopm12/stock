import { useEffect, useRef, useState } from "react";
import { CameraOff } from "lucide-react";

/** Continuous camera barcode scanner. The decoder library loads only in the browser. */
export function Scanner({ onScan, paused }: { onScan: (code: string) => void; paused?: boolean }) {
  const video = useRef<HTMLVideoElement>(null);
  const cb = useRef(onScan);
  cb.current = onScan;
  const last = useRef({ code: "", at: 0 });
  const [error, setError] = useState("");

  useEffect(() => {
    if (paused) return;
    let stop: (() => void) | undefined;
    let alive = true;
    (async () => {
      try {
        const { BrowserMultiFormatReader } = await import("@zxing/browser");
        if (!alive || !video.current) return;
        const reader = new BrowserMultiFormatReader();
        const controls = await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: "environment" } } }, video.current,
          (result) => {
            if (!result) return;
            const code = result.getText().trim();
            const now = Date.now();
            if (code === last.current.code && now - last.current.at < 1500) return;
            last.current = { code, at: now };
            navigator.vibrate?.(60);
            cb.current(code);
          },
        );
        if (!alive) controls.stop(); else stop = () => controls.stop();
        setError("");
      } catch (e) {
        setError(e instanceof Error && /permission|notallowed/i.test(e.name + e.message)
          ? "Camera permission was denied. Allow camera access in your browser settings."
          : "Camera not available on this device. Type the barcode below instead.");
      }
    })();
    return () => { alive = false; stop?.(); };
  }, [paused]);

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-3xl bg-foreground">
      <video ref={video} muted playsInline className="h-full w-full object-cover" />
      {!error && !paused && <div className="scan-frame pointer-events-none absolute inset-x-8 top-1/2 h-28 -translate-y-1/2 rounded-2xl border-2 border-primary-foreground/80"><div className="scan-line" /></div>}
      {(error || paused) && (
        <div className="absolute inset-0 grid place-items-center p-6 text-center text-sm text-background">
          <div><CameraOff className="mx-auto mb-2 h-8 w-8" />{error || "Camera paused"}</div>
        </div>
      )}
    </div>
  );
}
