CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  company text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name) VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1)));
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  sku text,
  category text,
  unit text NOT NULL DEFAULT 'pcs',
  price numeric NOT NULL DEFAULT 0,
  min_stock integer NOT NULL DEFAULT 5,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.items TO authenticated;
GRANT ALL ON public.items TO service_role;
ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own items" ON public.items FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  item_id uuid NOT NULL REFERENCES public.items(id) ON DELETE CASCADE,
  batch_no text NOT NULL,
  quantity integer NOT NULL DEFAULT 0,
  expiry_date date,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (item_id, batch_no)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.batches TO authenticated;
GRANT ALL ON public.batches TO service_role;
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own batches" ON public.batches FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  item_id uuid NOT NULL REFERENCES public.items(id) ON DELETE CASCADE,
  batch_id uuid REFERENCES public.batches(id) ON DELETE SET NULL,
  batch_no text,
  type text NOT NULL CHECK (type IN ('in','out','adjust')),
  quantity integer NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.movements TO authenticated;
GRANT ALL ON public.movements TO service_role;
ALTER TABLE public.movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own movements" ON public.movements FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.record_movement(_item_id uuid, _batch_no text, _type text, _qty integer, _note text DEFAULT NULL, _expiry date DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE b public.batches%ROWTYPE;
BEGIN
  IF _qty <= 0 AND _type <> 'adjust' THEN RAISE EXCEPTION 'Quantity must be positive'; END IF;
  SELECT * INTO b FROM public.batches WHERE item_id = _item_id AND batch_no = _batch_no FOR UPDATE;
  IF _type = 'in' THEN
    IF NOT FOUND THEN
      INSERT INTO public.batches (item_id, batch_no, quantity, expiry_date) VALUES (_item_id, _batch_no, _qty, _expiry) RETURNING * INTO b;
    ELSE
      UPDATE public.batches SET quantity = quantity + _qty, expiry_date = COALESCE(_expiry, expiry_date) WHERE id = b.id;
    END IF;
  ELSIF _type = 'out' THEN
    IF NOT FOUND THEN RAISE EXCEPTION 'Batch not found'; END IF;
    IF b.quantity < _qty THEN RAISE EXCEPTION 'Not enough stock in batch % (available %)', _batch_no, b.quantity; END IF;
    UPDATE public.batches SET quantity = quantity - _qty WHERE id = b.id;
  ELSE
    IF NOT FOUND THEN RAISE EXCEPTION 'Batch not found'; END IF;
    UPDATE public.batches SET quantity = _qty WHERE id = b.id;
  END IF;
  INSERT INTO public.movements (item_id, batch_id, batch_no, type, quantity, note) VALUES (_item_id, b.id, _batch_no, _type, _qty, _note);
END $$;
GRANT EXECUTE ON FUNCTION public.record_movement(uuid, text, text, integer, text, date) TO authenticated;