import { describe, expect, it } from "vitest";
import type { Item, Movement } from "@/lib/inventory";
import { buildItemReport, itemReportCsv, recentDateRange, reportBounds } from "@/lib/item-report";

const item = (id: string, name: string): Item => ({ id, name, sku: null, category: null, unit: "pcs", price: 10, min_stock: 5, created_at: "", image_url: null, barcode: null,
  batches: [{ id: "b", item_id: id, batch_no: "B1", quantity: 8, expiry_date: null, created_at: "" }, { id: "c", item_id: id, batch_no: "B2", quantity: 4, expiry_date: null, created_at: "" }] });
const movement = (id: string, type: Movement["type"], quantity: number, date: string): Movement => ({ id, item_id: "a", type, quantity, created_at: new Date(date).toISOString(), batch_no: "B1", note: null, items: null });
const filters = { start: "2026-10-22", end: "2026-10-22", search: "", itemId: "" };
const moves = [movement("1", "in", 10, "2026-10-22T00:00:00"), movement("2", "out", 3, "2026-10-22T23:59:59"), movement("3", "in", 20, "2026-10-23T00:00:00"), movement("4", "adjust", 8, "2026-10-22T12:00:00")];

describe("Detailed item reports", () => {
  it("includes both ends of a single day and excludes the following day", () => {
    const [row] = buildItemReport([item("a", "Keyboard")], moves, filters);
    expect(row?.stockIn).toBe(10); expect(row?.stockOut).toBe(3);
  });
  it("totals stock in and out across any selected date range", () => {
    const [row] = buildItemReport([item("a", "Keyboard")], moves, { ...filters, end: "2026-10-23" });
    expect(row?.stockIn).toBe(30); expect(row?.stockOut).toBe(3);
  });
  it("shows current available stock across batches separately from period movements", () => {
    expect(buildItemReport([item("a", "Keyboard")], moves, filters)[0]?.available).toBe(12);
  });
  it("filters item names case-insensitively and supports selecting one item", () => {
    const items = [item("a", "Keyboard"), item("b", "Mouse")];
    expect(buildItemReport(items, moves, { ...filters, search: "KEY" }).map((r) => r.item.id)).toEqual(["a"]);
    expect(buildItemReport(items, moves, { ...filters, itemId: "b" }).map((r) => r.item.id)).toEqual(["b"]);
  });
  it("downloads only filtered items with matching quantities and dates", () => {
    const rows = buildItemReport([item("a", "Keyboard"), item("b", "Mouse")], moves, { ...filters, itemId: "a" });
    expect(itemReportCsv(rows, filters.start, filters.end)[1]).toEqual(["Keyboard", null, null, "pcs", 12, 10, 3, "2026-10-22", "2026-10-22"]);
    expect(itemReportCsv(rows, filters.start, filters.end)).toHaveLength(2);
  });
  it("today preset selects exactly one calendar day", () => {
    expect(recentDateRange(1, new Date("2026-10-22T15:00:00"))).toEqual({ start: "2026-10-22", end: "2026-10-22" });
    expect(reportBounds("2026-10-23", "2026-10-22")).toBeNull();
  });
});