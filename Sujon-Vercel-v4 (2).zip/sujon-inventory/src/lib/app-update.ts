// Detects when a newly published version of the app is available and reloads
// into it, so an already-installed/old app (e.g. the Android shell or a
// long-lived tab) always picks up the latest build. Browser-safe.

const ASSET_STORAGE_KEY = "stockflow:build-assets";
const RELOAD_FLAG_KEY = "stockflow:update-reloaded-at";
const MIN_CHECK_INTERVAL_MS = 60_000;
const RELOAD_GUARD_MS = 30_000;

let lastCheckAt = 0;

/** Pull the hashed script/stylesheet asset URLs out of rendered root HTML. */
export function extractBuildAssets(html: string): string[] {
  const assets = new Set<string>();
  const scriptRe = /<script[^>]*\ssrc="([^"]+)"/g;
  const linkRe = /<link[^>]*\shref="([^"]+\.(?:css|js))"/g;
  for (const match of html.matchAll(scriptRe)) {
    const url = match[1];
    if (url) assets.add(url);
  }
  for (const match of html.matchAll(linkRe)) {
    const url = match[1];
    if (url) assets.add(url);
  }
  return [...assets]
    .filter((url) => !/^https?:\/\//i.test(url))
    .sort();
}

/** Only reload when a previous build was seen and it differs from the current one. */
export function shouldReloadAssets(previous: string | null, current: string): boolean {
  return previous != null && previous.length > 0 && previous !== current;
}

async function clearRuntimeCaches(): Promise<void> {
  try {
    if (typeof caches !== "undefined" && caches) {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
    }
  } catch {
    // Cache clearing is best-effort; the reload below already bypasses HTTP cache.
  }
}

/**
 * Fetches the current root page fresh (bypassing cache), compares its hashed
 * assets with the last seen build and, when a new build is live, clears any
 * runtime caches and reloads once. Returns true when a reload was triggered.
 */
export async function checkForAppUpdate(options?: { force?: boolean }): Promise<boolean> {
  if (typeof window === "undefined" || typeof document === "undefined") return false;
  if (import.meta.env.DEV) return false;

  const now = Date.now();
  if (!options?.force && now - lastCheckAt < MIN_CHECK_INTERVAL_MS) return false;
  lastCheckAt = now;

  try {
    const response = await fetch(window.location.origin + "/", { cache: "no-store" });
    if (!response.ok) return false;
    const html = await response.text();
    const current = extractBuildAssets(html).join("\n");
    if (!current) return false;

    const previous = window.localStorage.getItem(ASSET_STORAGE_KEY);
    window.localStorage.setItem(ASSET_STORAGE_KEY, current);
    if (!shouldReloadAssets(previous, current)) return false;

    // Time-bounded guard: never reload twice within a few seconds.
    const lastReload = Number(window.localStorage.getItem(RELOAD_FLAG_KEY) || 0);
    if (Number.isFinite(lastReload) && lastReload > 0 && now - lastReload < RELOAD_GUARD_MS) {
      return false;
    }
    window.localStorage.setItem(RELOAD_FLAG_KEY, String(now));

    await clearRuntimeCaches();
    window.location.reload();
    return true;
  } catch {
    return false;
  }
}
