import { useEffect } from "react";
import { useRouter, type ErrorComponentProps } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { isChunkLoadError, recoverChunkLoad } from "@/lib/chunk-recovery";
import { reportLovableError } from "@/lib/lovable-error-reporting";

export function PageLoadError({ error, reset }: ErrorComponentProps) {
  const router = useRouter();
  const chunkError = isChunkLoadError(error);
  useEffect(() => {
    if (isChunkLoadError(error)) {
      recoverChunkLoad(error);
      return;
    }
    reportLovableError(error, { boundary: "stockflow_page_error" });
  }, [error]);
  useEffect(() => {
    if (!chunkError) return;
    const retryOnline = () => recoverChunkLoad(error);
    window.addEventListener("online", retryOnline);
    return () => window.removeEventListener("online", retryOnline);
  }, [chunkError, error]);
  return <div role="alert" className="flex min-h-dvh items-center justify-center bg-background px-5">
    <div className="max-w-md text-center">
      <h1 className="text-xl font-bold">{chunkError ? "This page couldn't be downloaded" : "This page didn't load"}</h1>
      <p className="mt-2 text-sm text-muted-foreground">{chunkError ? "Check your connection, then reload the page. Your saved inventory is safe." : "Something went wrong. Try again."}</p>
      <Button className="mt-6 rounded-xl" onClick={() => {
        if (chunkError) { window.location.reload(); return; }
        void router.invalidate(); reset();
      }}>{chunkError ? "Reload page" : "Try again"}</Button>
    </div>
  </div>;
}