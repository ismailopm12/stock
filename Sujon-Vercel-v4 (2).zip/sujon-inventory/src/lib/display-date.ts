// Browser-safe display formatting: every date the app shows reads
// day/month/year, e.g. "22/10/2026" — matching dated batch numbers.
const pad = (n: number) => String(n).padStart(2, "0");

function toDate(value: string | number | Date): Date | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
  if (typeof value === "number") { const n = new Date(value); return Number.isNaN(n.getTime()) ? null : n; }
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value.trim());
  if (iso) {
    const d = new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

/** "22/10/2026" from a Date, an ISO day ("2026-10-22") or a timestamp. */
export function dayMonthYear(value: string | number | Date | null | undefined): string {
  const d = value == null ? null : toDate(value);
  return d ? `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}` : "";
}

/** "22/10/2026, 09:42" from a timestamp. */
export function dayMonthYearTime(value: string | number | Date | null | undefined): string {
  const d = value == null ? null : toDate(value);
  if (!d) return "";
  return `${dayMonthYear(d)}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
