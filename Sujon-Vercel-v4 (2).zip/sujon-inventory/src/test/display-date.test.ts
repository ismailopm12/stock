import { describe, expect, it } from "vitest";
import { dayMonthYear, dayMonthYearTime } from "@/lib/display-date";

describe("Day/month/year display dates", () => {
  it("shows an ISO day as day/month/year without timezone drift", () => {
    expect(dayMonthYear("2026-10-22")).toBe("22/10/2026");
    expect(dayMonthYear("2026-01-01")).toBe("01/01/2026");
  });

  it("shows timestamps in local time", () => {
    expect(dayMonthYearTime(new Date(2026, 9, 22, 9, 42))).toBe("22/10/2026, 09:42");
    expect(dayMonthYear("2026-10-22T20:00:00+03:00")).toBe("22/10/2026");
  });

  it("returns empty text for missing or invalid values", () => {
    expect(dayMonthYear(null)).toBe("");
    expect(dayMonthYear(undefined)).toBe("");
    expect(dayMonthYear("not a date")).toBe("");
    expect(dayMonthYearTime("")).toBe("");
  });
});
