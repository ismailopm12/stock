import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { AlertTriangle, CalendarClock, ChevronRight, ClipboardCheck, Download, FileSpreadsheet, Layers, LogOut, Tags, Wallet, UserRound, Building2, Save, LoaderCircle, ScanBarcode, Barcode as BarcodeIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { daysUntil, downloadCsv, itemsQuery, money, movementsQuery, profileQuery, stockStatus, totalQty } from "@/lib/inventory";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/app/ui";
import { ToolPanel, toolTitles, type ToolKey } from "@/components/app/ToolPanels";
import { StockSheet } from "@/components/app/StockSheet";
import { Flame, Snowflake } from "lucide-react";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profile — Sujon" }, { name: "description", content: "Your profile and power tools." }, { property: "og:title", content: "Profile — Sujon" }, { property: "og:description", content: "Manage your profile and inventory power tools." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(profileQuery), context.queryClient.ensureQueryData(itemsQuery), context.queryClient.ensureQueryData(movementsQuery()),
  ]),
  component: Profile,
});

type Tool = ToolKey | null;

function Profile() {
  const { data: profile } = useSuspenseQuery(profileQuery);
  const { data: items } = useSuspenseQuery(itemsQuery);
  const { data: moves } = useSuspenseQuery(movementsQuery());
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [tool, setTool] = useState<Tool>(null);
  const [restock, setRestock] = useState<string | null>(null);
  const [name, setName] = useState(profile?.full_name ?? "");
  const [saving, setSaving] = useState(false);
  const [company, setCompany] = useState(profile?.company ?? "");

  const low = items.filter((i) => stockStatus(i) !== "in");
  const allBatches = items.flatMap((i) => i.batches.map((b) => ({ ...b, item: i })));
  const expiring = allBatches.filter((b) => b.expiry_date && b.quantity > 0 && daysUntil(b.expiry_date) <= 30)
    .sort((a, b) => (a.expiry_date ?? "").localeCompare(b.expiry_date ?? ""));

  async function saveProfile() {
    if (!profile || saving) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("profiles").upsert({ id: profile.id, full_name: name.trim(), company: company.trim() });
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Profile saved");
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not save profile"); }
    finally { setSaving(false); }
  }

  async function signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) { toast.error(error.message); return; }
    await qc.cancelQueries();
    qc.clear();
    await navigate({ to: "/auth", replace: true });
  }

  const tools: { k: Tool | "exportItems" | "exportMoves" | "scan" | "labels"; title: string; hint: string; icon: typeof Layers; tone: string; badge?: number }[] = [
    { k: "scan", title: "Barcode scanner (in / out / audit)", hint: "", icon: ScanBarcode, tone: "bg-primary-soft text-accent-foreground" },
    { k: "labels", title: "Print all barcodes", hint: "", icon: BarcodeIcon, tone: "bg-mint-soft text-mint" },
    { k: "low", title: "Low stock alerts", hint: "Items at or below minimum", icon: AlertTriangle, tone: "bg-warning-soft text-warning", badge: low.length },
    { k: "expiry", title: "Expiry tracker", hint: "Batches expiring in 30 days", icon: CalendarClock, tone: "bg-danger-soft text-destructive", badge: expiring.length },
    { k: "batches", title: "Batch explorer", hint: "Every batch across products", icon: Layers, tone: "bg-primary-soft text-accent-foreground" },
    { k: "valuation", title: "Stock valuation", hint: "Value per product", icon: Wallet, tone: "bg-mint-soft text-mint" },
    { k: "categories", title: "Category summary", hint: "Units & value by category", icon: Tags, tone: "bg-primary-soft text-accent-foreground" },
    { k: "count", title: "Reorder planner", hint: "Suggested reorder quantities", icon: ClipboardCheck, tone: "bg-success-soft text-success" },
    { k: "movers", title: "Top movers", hint: "", icon: Flame, tone: "bg-danger-soft text-destructive" },
    { k: "dead", title: "Dead stock finder", hint: "", icon: Snowflake, tone: "bg-primary-soft text-accent-foreground" },
    { k: "exportItems", title: "Export inventory CSV", hint: "Items with batches", icon: FileSpreadsheet, tone: "bg-mint-soft text-mint" },
    { k: "exportMoves", title: "Export history CSV", hint: "All stock movements", icon: Download, tone: "bg-success-soft text-success" },
  ];

  function runTool(k: (typeof tools)[number]["k"]) {
    if (k === "scan") { void navigate({ to: "/scan" }); return; }
    if (k === "labels") { void navigate({ to: "/barcodes" }); return; }
    if (k === "exportItems") {
      downloadCsv("inventory.csv", [["Item", "SKU", "Barcode", "Category", "Unit", "Price", "Min", "Total qty", "Batches"],
        ...items.map((i) => [i.name, i.sku, i.barcode, i.category, i.unit, i.price, i.min_stock, totalQty(i), i.batches.map((b) => `${b.batch_no}:${b.quantity}`).join(" | ")])]);
    } else if (k === "exportMoves") {
      downloadCsv("history.csv", [["Date", "Item", "Batch", "Type", "Qty", "Note"],
        ...moves.map((m) => [new Date(m.created_at).toISOString(), m.items?.name ?? "", m.batch_no, m.type, m.quantity, m.note])]);
    } else setTool(k);
  }

  return (
    <div>
      <PageHeader icon={UserRound} title="Profile" subtitle="Account & workspace" />
      <div className="px-5">
      <section className="profile-identity flex items-center gap-4 border-y border-border py-5">
        <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-primary-soft text-2xl font-extrabold text-primary">{(name || "U").charAt(0).toUpperCase()}</div>
        <div className="min-w-0"><h2 className="break-words text-lg font-extrabold">{name || "Your name"}</h2><p className="mt-1 break-all text-xs text-muted-foreground">{profile?.email}</p>{company && <p className="mt-2 flex items-start gap-1.5 break-words text-xs font-medium"><Building2 className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />{company}</p>}</div>
      </section>
      <div className="grid grid-cols-3 divide-x divide-border py-5 text-center">
        <div><p className="text-xl font-extrabold tabular-nums">{items.length}</p><p className="mt-1 text-xs text-muted-foreground">Items</p></div>
        <div><p className="text-xl font-extrabold tabular-nums">{allBatches.length}</p><p className="mt-1 text-xs text-muted-foreground">Batches</p></div>
        <div><p className="text-xl font-extrabold tabular-nums">{moves.length}</p><p className="mt-1 text-xs text-muted-foreground">Movements</p></div>
      </div>
      <div className="space-y-3 border-y border-border py-5">
        <h2 className="flex items-center gap-2 font-bold"><UserRound className="h-4 w-4 text-primary" />Account details</h2>
        <label htmlFor="profile-name" className="text-xs font-semibold text-muted-foreground">Full name</label>
        <Input id="profile-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="h-12 rounded-xl bg-card" />
        <label htmlFor="profile-company" className="text-xs font-semibold text-muted-foreground">Company / store</label>
        <Input id="profile-company" value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Company / store" className="h-12 rounded-xl bg-card" />
        <Button disabled={saving} onClick={saveProfile} className="h-12 w-full rounded-xl">{saving ? <LoaderCircle className="animate-spin" /> : <Save />}{saving ? "Saving…" : "Save profile"}</Button>
      </div>

      <h2 className="mt-6 mb-3 text-lg font-extrabold">Inventory tools</h2>
      <div className="grid gap-x-5 md:grid-cols-2">
        {tools.map((t) => (
          <Button variant="ghost" key={t.k} aria-label={t.title} onClick={() => runTool(t.k)} className="tool-row tap relative h-auto min-h-18 justify-start gap-3 whitespace-normal rounded-none border-b border-border px-0 py-4 text-left hover:bg-secondary">
            <div className={`grid h-10 w-10 place-items-center rounded-xl ${t.tone}`}><t.icon className="h-5 w-5" /></div>
            <p className="min-w-0 flex-1 text-sm font-semibold leading-snug">{t.title}</p>
            {!!t.badge && <span className="shrink-0 rounded-full bg-danger-soft px-2 py-0.5 text-[10px] font-bold text-destructive">{t.badge}</span>}
            <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            
          </Button>
        ))}
      </div>

      <Button variant="ghost" onClick={signOut} className="tap mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-danger-soft font-semibold text-destructive"><LogOut className="h-4 w-4" />Sign out</Button>

      <p className="mt-4 text-center text-xs font-medium text-muted-foreground">Development by Sujon</p>

      </div>
      <Drawer open={!!tool} onOpenChange={(o) => !o && setTool(null)}>
        <DrawerContent className="mx-auto max-h-[85vh] max-w-lg">
          {tool && <>
            <DrawerHeader><DrawerTitle>{toolTitles[tool]}</DrawerTitle></DrawerHeader>
            <div onClick={(e) => { if ((e.target as HTMLElement).closest("a")) setTool(null); }} className="overflow-y-auto px-4 pb-8"><ToolPanel tool={tool} items={items} moves={moves} onRestock={(id) => { setTool(null); setRestock(id); }} /></div>
          </>}
        </DrawerContent>
      </Drawer>
      <StockSheet open={!!restock} onOpenChange={(o) => !o && setRestock(null)} items={items} defaultItemId={restock ?? ""} defaultMode="in" defaultBatch="" />
    </div>
  );
}

