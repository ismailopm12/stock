ALTER TABLE public.batches ADD COLUMN quantity_decimal numeric(18,3) NOT NULL DEFAULT 0;
UPDATE public.batches SET quantity_decimal = quantity;
ALTER TABLE public.movements ADD COLUMN quantity_decimal numeric(18,3) NOT NULL DEFAULT 0;
UPDATE public.movements SET quantity_decimal = quantity;
ALTER TABLE public.items ADD COLUMN min_stock_decimal numeric(18,3) NOT NULL DEFAULT 5;
UPDATE public.items SET min_stock_decimal = min_stock;
COMMENT ON COLUMN public.batches.quantity IS 'DEPRECATED: use quantity_decimal; retained for old clients';
COMMENT ON COLUMN public.movements.quantity IS 'DEPRECATED: use quantity_decimal; retained for old clients';
COMMENT ON COLUMN public.items.min_stock IS 'DEPRECATED: use min_stock_decimal; retained for old clients';
CREATE TABLE public.categories (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL DEFAULT auth.uid(), name text NOT NULL CHECK (length(trim(name)) > 0), created_at timestamptz NOT NULL DEFAULT now());
CREATE UNIQUE INDEX categories_owner_name ON public.categories(user_id, lower(trim(name)));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own categories" ON public.categories FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
INSERT INTO public.categories (user_id,name) SELECT DISTINCT ON (user_id,lower(trim(category))) user_id,trim(category) FROM public.items WHERE category IS NOT NULL AND trim(category) <> '' ON CONFLICT DO NOTHING;
CREATE OR REPLACE FUNCTION public.record_movement(_item_id uuid, _batch_no text, _type text, _amount numeric, _note text DEFAULT NULL, _expiry date DEFAULT NULL) RETURNS void LANGUAGE plpgsql SET search_path = public AS $$
DECLARE b public.batches%ROWTYPE; v_unit text; v_new numeric;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Sign in required'; END IF;
 SELECT unit INTO v_unit FROM public.items WHERE id=_item_id AND user_id=auth.uid() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Item not found'; END IF;
 IF _type NOT IN ('in','out','adjust') OR _type IS NULL THEN RAISE EXCEPTION 'Invalid movement type'; END IF;
 IF _amount IS NULL OR _amount::text IN ('NaN','Infinity','-Infinity') OR _amount < 0 OR _amount > 999999999 OR _amount <> round(_amount,3) OR (_type <> 'adjust' AND _amount=0) THEN RAISE EXCEPTION 'Enter a positive quantity with up to 3 decimal places'; END IF;
 IF lower(trim(v_unit)) NOT IN ('kg','kilogram','kilograms','g','gram','grams','lb','lbs','pound','pounds','oz','l','liter','litre','liters','litres','ml','m','meter','metre','cm') AND _amount <> trunc(_amount) THEN RAISE EXCEPTION 'This unit requires a whole-number quantity'; END IF;
 IF trim(coalesce(_batch_no,''))='' THEN RAISE EXCEPTION 'Batch number required'; END IF;
 SELECT * INTO b FROM public.batches WHERE item_id=_item_id AND batch_no=trim(_batch_no) AND user_id=auth.uid() FOR UPDATE;
 IF _type='in' THEN
  IF NOT FOUND THEN
   INSERT INTO public.batches(item_id,batch_no,quantity_decimal,quantity,expiry_date) VALUES (_item_id,trim(_batch_no),_amount,trunc(_amount)::integer,_expiry) RETURNING * INTO b;
  ELSE
   v_new=b.quantity_decimal+_amount;
   IF v_new > 999999999 THEN RAISE EXCEPTION 'Stock limit exceeded'; END IF;
   UPDATE public.batches SET quantity_decimal=v_new,quantity=trunc(v_new)::integer,expiry_date=coalesce(_expiry,expiry_date) WHERE id=b.id;
  END IF;
 ELSE
  IF NOT FOUND THEN RAISE EXCEPTION 'Batch not found'; END IF;
  IF _type='out' AND b.quantity_decimal < _amount THEN RAISE EXCEPTION 'Not enough stock in batch'; END IF;
  v_new=CASE WHEN _type='out' THEN b.quantity_decimal-_amount ELSE _amount END;
  UPDATE public.batches SET quantity_decimal=v_new,quantity=trunc(v_new)::integer WHERE id=b.id;
 END IF;
 INSERT INTO public.movements(item_id,batch_id,batch_no,type,quantity_decimal,quantity,note) VALUES (_item_id,b.id,trim(_batch_no),_type,_amount,trunc(_amount)::integer,_note);
END $$;
REVOKE ALL ON FUNCTION public.record_movement(uuid,text,text,numeric,text,date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.record_movement(uuid,text,text,numeric,text,date) TO authenticated;
CREATE OR REPLACE FUNCTION public.record_movement(_item_id uuid, _batch_no text, _type text, _qty integer, _note text DEFAULT NULL, _expiry date DEFAULT NULL) RETURNS void LANGUAGE plpgsql SET search_path=public AS $$ BEGIN PERFORM public.record_movement(_item_id,_batch_no,_type,_qty::numeric,_note,_expiry); END $$;