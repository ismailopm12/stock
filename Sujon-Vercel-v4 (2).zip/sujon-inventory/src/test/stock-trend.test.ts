import { describe, expect, it } from "vitest";
import { stockTrend } from "../lib/stock-trend";
import type { Movement } from "../lib/inventory";
const move = (type: Movement["type"], quantity: number, unit: string, day: string): Movement => ({ id: day, item_id: "item", batch_no: "B1", type, quantity, note: null, created_at: `${day}T12:00:00`, items: { name: "Test", unit } });
describe("stock trend", () => {
  const moves = [move("in", 2.75, "kg", "2026-10-22"), move("out", 0.625, "kg", "2026-10-22"), move("in", 12, "pcs", "2026-10-22"), move("adjust", 3, "kg", "2026-10-22"), move("in", 9, "kg", "2026-10-23")];
  it("counts in/out entries without mixing units or adjustments", () => {
    expect(stockTrend(moves, "2026-10-22", "2026-10-22", "movements")[0]).toMatchObject({ stockIn: 2, stockOut: 1 });
  });
  it("shows exact quantities for one selected unit", () => {
    expect(stockTrend(moves, "2026-10-22", "2026-10-22", "kg")[0]).toMatchObject({ stockIn: 2.75, stockOut: 0.625 });
  });
  it("includes the final day and buckets longer ranges without losing totals", () => {
    const result = stockTrend(moves, "2026-08-01", "2026-10-23", "kg");
    expect(result.length).toBeLessThanOrEqual(31);
    expect(result.reduce((sum, bucket) => sum + bucket.stockIn, 0)).toBe(11.75);
  });
  it("returns no data for reversed dates", () => expect(stockTrend(moves, "2026-10-23", "2026-10-22", "kg")).toEqual([]));
});