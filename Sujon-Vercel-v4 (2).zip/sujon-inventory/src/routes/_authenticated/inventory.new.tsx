import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { genBatchNo, itemsQuery } from "@/lib/inventory";
import { insertItem, saveOpeningStock, type ItemDraft } from "@/lib/create-item";
import { uploadItemImage } from "@/lib/item-image";
import { ItemForm, type ItemImageSelection } from "@/components/app/ItemForm";

export const Route = createFileRoute("/_authenticated/inventory/new")({
  head: () => ({ meta: [
    { title: "Add item — Sujon" }, { name: "description", content: "Create an inventory item with a photo, pricing and opening batch stock." },
    { property: "og:title", content: "Add item — Sujon" }, { property: "og:description", content: "Create an inventory item with a photo, pricing and opening batch stock." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: NewItem,
});

const emptyDraft = (): ItemDraft => ({ name: "", sku: "", category: "", unit: "pcs", price: "", min_stock: "5", qty: "", batch: genBatchNo(), expiry: "" });

function NewItem() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [draft] = useState<ItemDraft>(emptyDraft);
  const createdId = useRef<string | null>(null);

  async function save(f: ItemDraft, image: ItemImageSelection) {
    let id = createdId.current;
    try {
      if (!id) { id = await insertItem(f); createdId.current = id; }
      if (image.file) {
        const path = await uploadItemImage(id, image.file);
        const { error } = await supabase.from("items").update({ image_url: path }).eq("id", id);
        if (error) throw new Error(error.message);
      }
      await saveOpeningStock(id, f);
      await qc.invalidateQueries({ queryKey: itemsQuery.queryKey });
      await qc.invalidateQueries({ queryKey: ["movements"] });
      toast.success("Item saved");
      await navigate({ to: "/inventory/$id", params: { id } });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Please try again.";
      throw new Error(id ? `Item saved, but finishing failed: ${message}` : `Could not save item: ${message}`);
    }
  }

  return <ItemForm mode="new" initial={draft} backTo="/inventory" onSubmit={save} />;
}
