# Sujon — complete Vercel upload guide

## What this folder is

This is Sujon's editable source project, not a static website. Vercel builds the pages and server automatically. Upload the complete extracted folder, not only `src`, `public`, or a ZIP file. Hosting it does not copy or move your inventory, user accounts, or photos. Keeping the current backend settings keeps the same existing data.

## 1. The app now lives inside one folder

Everything is wrapped in a single folder called `sujon-inventory`. That is the point: on GitHub the whole app is one folder, so you can delete it later by deleting that one folder instead of picking files out one by one.

```text
sujon-inventory/         <-- the whole app, one folder
  package.json           Node version and app commands
  bun.lock               Dependency lockfile
  vite.config.ts         Chooses Vercel's server output automatically
  vercel.json            Vercel build and installation settings
  tsconfig.json
  components.json
  src/                   All app screens, stock tools and sign-in logic
  public/                Public assets
  drizzle/               Existing database schema and migration history
  .env.example           Names of the required hosting settings
  .gitignore             Keeps local/generated files out of GitHub
  DEPLOY_VERCEL.md       This guide
```

There is no `index.html` or single root HTML file to upload: this app generates its pages on the server. Never upload `node_modules`, `.git`, `.vercel`, or `dist`. Vercel creates what it needs.

Because the app is inside a folder, Vercel's **Root Directory** must be set to `sujon-inventory` (section 3). If you skip that, the build fails with "Cannot find package.json".

## 2. Copy the backend settings

Before importing in Vercel, open this project's `.env` file in the Lovable code editor. Copy the values privately into Vercel's Environment Variables. Do not paste them into chat or publish the `.env` file to GitHub.

| Vercel variable | Copy value from the Lovable project |
| --- | --- |
| `VITE_SUPABASE_URL` | `VITE_SUPABASE_URL` |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | `VITE_SUPABASE_PUBLISHABLE_KEY` |
| `SUPABASE_URL` | Same value as `VITE_SUPABASE_URL` |
| `SUPABASE_PUBLISHABLE_KEY` | Same value as `VITE_SUPABASE_PUBLISHABLE_KEY` |

Enable these for **Production** and **Preview**; Development is optional. These are public connection settings, not an administrator credential. Do not add a service-role key: Sujon's application flows do not use one. Vercel supplies `VERCEL` automatically; do not add it yourself. The project-ID setting is not needed by the current application.

The ZIP intentionally contains only an empty `.env.example`, not the current backend values. For local development, copy it to `.env` and fill the four values privately.

## 3. Upload through GitHub (easiest without a terminal)

1. Download and extract the ZIP on a computer. You get one folder: `sujon-inventory`.
2. On GitHub, create a new **private** repository, for example `sujon-inventory`.
3. Choose **uploading an existing file**, or **Add file → Upload files**.
4. Drag the **whole `sujon-inventory` folder** into GitHub's upload area. GitHub keeps it as a folder, so the repository shows `sujon-inventory/package.json` rather than loose files at the top level.
5. Include `src`, `public`, `drizzle`, and all root configuration files. Hidden files may need to be selected separately. Never upload a filled `.env` file.
6. Click **Commit changes**.
7. Sign in to Vercel, choose **Add New → Project**, connect GitHub, and **Import** this repository.
8. Use these settings:

| Setting | Value |
| --- | --- |
| Framework Preset | **Other** |
| Root Directory | **`sujon-inventory`** (click Edit and type it) |
| Build Command | `npm run build` |
| Install Command | `npm install` |
| Output Directory | Leave unset; do not enter `dist` or `public` |
| Node.js Version | **22.x**, also specified in `package.json` |

9. Add the four environment variables from section 2.
10. Click **Deploy**. Wait until Vercel reports **Ready**, then open the deployment URL.

If you instead uploaded the folder's contents, `package.json` sits at the repository root and Root Directory should be left at its default. Do not mix the two: one folder in, one name in Root Directory. Vercel does not accept a ZIP as a GitHub source project; extract it first. The CLI method below uploads a local folder directly without GitHub.

## 4. Deleting the app from GitHub later

Because the app is one folder, removal is one action:

- **In GitHub's web page:** open the `sujon-inventory` folder, click the **⋯** (three dots) at the top right of the file list, choose **Delete directory**, then **Commit changes**. The whole app is gone from that branch; Vercel's next build fails until you remove the project.
- **From a terminal:** `git rm -r sujon-inventory` then `git commit -m "remove app"` and `git push`.
- **Everything at once:** delete the repository itself in GitHub **Settings → General → Danger Zone → Delete this repository**, and delete the Vercel project in **Settings → Delete Project**.

Deleting the source does not touch your inventory data, accounts or photos — those live in the backend, not in the repository.

## 5. Direct upload from a computer terminal

Install Node.js 22 first, then open a terminal **inside** the `sujon-inventory` folder (the one containing `package.json`).

```bash
npm install -g vercel
vercel login
vercel link
```

When prompted, choose your Vercel account/workspace, create a project if necessary, and select `./` as the code directory. If asked to override settings, use the values in section 3.

Add the four settings interactively; paste the matching value at each prompt and mark it as non-sensitive public configuration when asked:

```bash
vercel env add VITE_SUPABASE_URL production
vercel env add VITE_SUPABASE_PUBLISHABLE_KEY production
vercel env add SUPABASE_URL production
vercel env add SUPABASE_PUBLISHABLE_KEY production
```

For a test deployment, add the same four for Preview:

```bash
vercel env add VITE_SUPABASE_URL preview
vercel env add VITE_SUPABASE_PUBLISHABLE_KEY preview
vercel env add SUPABASE_URL preview
vercel env add SUPABASE_PUBLISHABLE_KEY preview
vercel
```

After checking the test site, deploy the live version:

```bash
vercel --prod
```

Use `vercel env add` rather than placing private credentials in command arguments. If you change a setting later, redeploy: the browser settings are bundled during the build.

## 6. Sign-in, recovery and photos after deployment

1. Test email/password sign-in with an existing account.
2. Open Inventory, an item, History, Reports, Scan and Profile. Refresh an item page directly; it should remain accessible.
3. Check existing photos load. Photos remain in the same private storage; no public bucket is needed.
4. The new Vercel address must be accepted by the backend's allowed sign-in redirects for `/auth` and `/reset-password`. Do not replace the current site's address if you still use Lovable or the Android app.
5. Google currently uses Lovable's sign-in service. Google on an external Vercel address is **not verified** and may need direct Google sign-in configured; publishing on Vercel alone does not configure it.
6. Email/password sign-in, registration confirmation and password-reset delivery on your new Vercel site are **not verified until it is deployed and tested**.

Once you have the Vercel URL, share the public site address (not a token or password) so the redirect and Google setup can be checked.

## 7. Current backend versus a new backend

Using the current settings keeps your current inventory, history, users and photos. There is no automatic data transfer.

For a separate backend you own, first apply the complete Sujon database setup you received, configure email/Google providers, private photo storage, and allowed redirects there, then use that backend's public settings in all four Vercel variables. Existing data and accounts will not appear unless separately migrated. Never use the previously exposed service-role key; rotate that credential at its issuing service.

## 8. Updating later

- **GitHub:** upload or push changed source files inside `sujon-inventory` to the connected branch; Vercel redeploys that branch automatically.
- **CLI:** run `vercel --prod` again from inside the updated `sujon-inventory` folder.
- Later Lovable edits do not automatically update an independently uploaded GitHub repository. Sync your source or upload a new export.
- Lovable publishing updates the Lovable site only, not your separate Vercel project.
- The existing Android APK still opens the Lovable site. It does not switch to Vercel automatically; its site address must be changed in a new APK.
- Database changes affect the shared backend immediately, even without a Vercel or Lovable publish.

## 9. Common deployment problems

| Problem | What to check |
| --- | --- |
| Cannot find `package.json` | Root Directory must be `sujon-inventory` (or the app must be at the repository root) |
| Missing backend settings | Add all four settings, enable the correct environment, then redeploy |
| `nodeVersion` is rejected | Use this package's `vercel.json`; Node belongs in `package.json` engines / Vercel settings |
| Empty output / invalid output directory | Remove an Output Directory override; do not use `dist` |
| Confirmation/reset link returns to old site | New site's auth/reset addresses need backend redirect permission |
| Google rejects the domain | External Google sign-in configuration still needs verification |
| Existing photos fail | Check that you kept the same backend and signed-in account |
| Camera will not open | Use the HTTPS deployment URL and allow camera permission |
| Refresh gives 404 | Confirm the source contains the route and deployment completed; no static redirect file is needed |

## Verification status

The source is configured for Vercel, and the app's preview is checked separately. This package does not mean a new Vercel deployment exists. The final Vercel deployment, auth redirects and external Google sign-in still need checks on your actual deployment address.
