import { Button } from "@/components/ui/button";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Package, Plus, Search, LayoutGrid, List, X } from "lucide-react";
import { itemsQuery, money, stockStatus, totalQty, type StockStatus } from "@/lib/inventory";
import { useItemImage } from "@/lib/item-image";
import { Empty, PageHeader, StatusBadge } from "@/components/app/ui";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/inventory/")({
  head: () => ({ meta: [{ title: "Inventory — Sujon" }, { name: "description", content: "All inventory items." }, { property: "og:title", content: "Inventory — Sujon" }, { property: "og:description", content: "Browse inventory items and their stock levels." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  validateSearch: (search: Record<string, unknown>): { status?: StockStatus } => {
    const status = search["status"];
    return status === "in" || status === "low" || status === "out" ? { status } : {};
  },
  loader: ({ context }) => context.queryClient.ensureQueryData(itemsQuery),
  component: Inventory,
});

const filters: { k: "all" | StockStatus; label: string }[] = [
  { k: "all", label: "All" }, { k: "in", label: "In Stock" }, { k: "low", label: "Low Stock" }, { k: "out", label: "Out of Stock" },
];

function Inventory() {
  const { data: items } = useSuspenseQuery(itemsQuery);
  const [q, setQ] = useState("");
  const { status } = Route.useSearch();
  const navigate = Route.useNavigate();
  const f = status ?? "all";
  const setF = (value: "all" | StockStatus) => navigate({ search: value === "all" ? {} : { status: value }, replace: true });
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState("recent");
  const [view, setView] = useState<"list" | "grid">("list");
  const categories = [...new Set(items.flatMap((item) => item.category ? [item.category] : []))].sort();
  const list = useMemo(() => items.filter((i) =>
    (f === "all" || stockStatus(i) === f) && (!category || i.category === category) &&
    `${i.name} ${i.sku ?? ""} ${i.barcode ?? ""} ${i.category ?? ""}`.toLowerCase().includes(q.toLowerCase())).sort((a, b) => sort === "name" ? a.name.localeCompare(b.name) : sort === "stock" ? totalQty(a) - totalQty(b) : sort === "value" ? totalQty(b) * b.price - totalQty(a) * a.price : new Date(b.created_at).getTime() - new Date(a.created_at).getTime()), [items, q, f, category, sort]);

  return (
    <div>
      <PageHeader title="Inventory" subtitle={`${items.length} products`} action={
        <Link to="/inventory/new" className="tap flex items-center gap-1 rounded-full bg-card px-4 py-2 text-sm font-semibold shadow-soft"><Plus className="h-4 w-4" />Add</Link>
      } />
      <div className="px-5">
        <div className="flex h-12 items-center gap-2 rounded-2xl bg-card px-4 shadow-soft">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input aria-label="Search inventory" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, SKU, category" className="w-full bg-transparent text-sm outline-none" />
        </div>
        <div className="-mx-5 mt-3 flex gap-2 overflow-x-auto px-5 pb-1">
          {filters.map((x) => (
            <Button variant="ghost" key={x.k} aria-pressed={f === x.k} onClick={() => setF(x.k)} className={cn("tap shrink-0 rounded-full px-4 py-2 text-sm font-semibold",
              f === x.k ? "bg-primary-soft text-accent-foreground" : "bg-card text-muted-foreground shadow-soft")}>{x.label}</Button>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <select aria-label="Inventory category" value={category} onChange={(e) => setCategory(e.target.value)} className="h-11 min-w-0 rounded-xl border border-input bg-card px-3 text-xs"><option value="">All categories</option>{categories.map((name) => <option key={name}>{name}</option>)}</select>
          <select aria-label="Sort inventory" value={sort} onChange={(e) => setSort(e.target.value)} className="h-11 min-w-0 rounded-xl border border-input bg-card px-3 text-xs"><option value="recent">Newest first</option><option value="name">Name A–Z</option><option value="stock">Lowest stock</option><option value="value">Highest value</option></select>
        </div>
        <div className="mt-3 flex items-center justify-between gap-2"><p className="text-xs font-medium text-muted-foreground">{list.length} results</p><div className="flex items-center gap-1">
          {(q || f !== "all" || category) && <Button variant="ghost" size="sm" onClick={() => { setQ(""); setF("all"); setCategory(""); }}><X />Clear</Button>}
          <Button title="List view" aria-label="List view" aria-pressed={view === "list"} size="icon" variant={view === "list" ? "secondary" : "ghost"} onClick={() => setView("list")}><List /></Button>
          <Button title="Grid view" aria-label="Grid view" aria-pressed={view === "grid"} size="icon" variant={view === "grid" ? "secondary" : "ghost"} onClick={() => setView("grid")}><LayoutGrid /></Button>
        </div></div>
      </div>
      <div className={cn("inventory-results mt-3 grid gap-2.5 px-5", view === "grid" ? "grid-cols-2 lg:grid-cols-3" : "grid-cols-1")}>
        {list.map((i) => (
          <Link key={i.id} to="/inventory/$id" params={{ id: i.id }} className={cn("card-soft tap native-list-item flex gap-3 p-3", view === "grid" ? "flex-col items-start" : "items-center")}>
            <ItemThumb id={i.id} name={i.name} imageUrl={i.image_url} />
            <div className="min-w-0 w-full flex-1">
              <p className="truncate font-semibold">{i.name}</p>
              <p className="truncate text-xs text-muted-foreground">SKU: {i.sku || "—"} · {i.batches.length} batches</p>
              <div className={cn("mt-1 flex gap-2", view === "grid" ? "flex-col items-start" : "flex-wrap items-center justify-between")}>
                <span className="text-xs font-medium">{totalQty(i)} {i.unit} · {money(Number(i.price))}</span>
                <StatusBadge s={stockStatus(i)} />
              </div>
            </div>
          </Link>
        ))}
      </div>
      {!list.length && <div className="mt-4"><Empty title={items.length ? "No matching items" : "No items yet"} hint={items.length ? "No products match the selected filters." : "Add your first product to start tracking."} action={
        <Link to="/inventory/new" className="mt-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Add product</Link>} /></div>}
    </div>
  );
}

function ItemThumb({ name, imageUrl }: { id: string; name: string; imageUrl: string | null }) {
  const url = useItemImage(imageUrl);
  if (!url) return <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-primary-soft text-accent-foreground"><Package className="h-6 w-6" /></div>;
  return <img src={url} alt={name} className="h-14 w-14 shrink-0 rounded-2xl object-contain bg-card p-1" />;
}
