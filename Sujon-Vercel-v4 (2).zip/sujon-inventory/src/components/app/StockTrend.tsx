import { useEffect, useId, useMemo, useState } from "react";
import { Activity, ArrowDownLeft, ArrowUpRight, BarChart3, ChartNoAxesCombined } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import type { Movement } from "@/lib/inventory";
import { recentDateRange } from "@/lib/item-report";
import { stockTrend } from "@/lib/stock-trend";
import { cn } from "@/lib/utils";

export function useChartMotion() {
  const [animate, setAnimate] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setAnimate(!media.matches);
    update(); media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  return animate;
}

export function StockTrend({ moves, dates }: { moves: Movement[]; dates?: { start: string; end: string } }) {
  const [days, setDays] = useState(7);
  const [mode, setMode] = useState<"area" | "bar">("area");
  const [metric, setMetric] = useState("movements");
  const [visible, setVisible] = useState({ stockIn: true, stockOut: true });
  const range = dates ?? recentDateRange(days);
  const data = useMemo(() => stockTrend(moves, range.start, range.end, metric), [moves, range.start, range.end, metric]);
  const units = [...new Set(moves.flatMap((move) => move.items?.unit ? [move.items.unit] : []))].sort();
  const animate = useChartMotion();
  const id = useId().replace(/:/g, "");
  const totals = data.reduce((sum, day) => ({ stockIn: sum.stockIn + day.stockIn, stockOut: sum.stockOut + day.stockOut }), { stockIn: 0, stockOut: 0 });
  const axes = [<CartesianGrid key="grid" vertical={false} stroke="var(--border)" strokeDasharray="3 5" />, <XAxis key="x" dataKey="label" minTickGap={32} tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />, <YAxis key="y" width={35} allowDecimals={metric !== "movements"} tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />, <Tooltip key="tooltip" contentStyle={{ background: "var(--popover)", color: "var(--popover-foreground)", border: "1px solid var(--border)", borderRadius: 8, boxShadow: "var(--shadow-soft)" }} cursor={{ stroke: "var(--border)" }} />];
  return <section aria-label="Stock trend" className="trend-section mt-6 border-t border-border px-5 pt-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h2 className="flex items-center gap-2 font-bold"><Activity className="animated-icon h-5 w-5 text-mint" />Stock trend</h2>
      <div className="flex items-center gap-1 rounded-xl bg-muted p-1">
        <Button size="icon" variant="ghost" title="Area chart" aria-label="Area chart" aria-pressed={mode === "area"} onClick={() => setMode("area")} className={cn("h-8 w-8 rounded-lg", mode === "area" && "bg-card shadow-soft")}><ChartNoAxesCombined /></Button>
        <Button size="icon" variant="ghost" title="Bar chart" aria-label="Bar chart" aria-pressed={mode === "bar"} onClick={() => setMode("bar")} className={cn("h-8 w-8 rounded-lg", mode === "bar" && "bg-card shadow-soft")}><BarChart3 /></Button>
      </div>
    </div>
    <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
      {!dates && <div className="flex gap-1 rounded-xl bg-muted p-1">{[7, 30, 90].map((day) => <Button key={day} variant="ghost" size="sm" aria-pressed={days === day} onClick={() => setDays(day)} className={cn("rounded-lg", days === day && "bg-card shadow-soft")}>{day} days</Button>)}</div>}
      <select aria-label="Chart measurement" value={metric} onChange={(e) => setMetric(e.target.value)} className="native-control h-10 min-w-0 rounded-xl border border-input bg-card px-3 text-xs font-semibold"><option value="movements">Movement count</option>{units.map((unit) => <option key={unit} value={unit}>Quantity · {unit}</option>)}</select>
    </div>
    <div className="mt-4 grid grid-cols-2 gap-3">{(["stockIn", "stockOut"] as const).map((key) => <Button key={key} variant={key === "stockIn" ? "stockIn" : "stockOut"} aria-pressed={visible[key]} onClick={() => setVisible((prev) => ({ ...prev, [key]: !prev[key] }))} className={cn("h-auto min-h-16 justify-start rounded-xl px-3 py-3", !visible[key] && "opacity-45")}>
      {key === "stockIn" ? <ArrowDownLeft /> : <ArrowUpRight />}<span className="min-w-0 text-left"><span className="block text-[11px]">{key === "stockIn" ? "Stock in" : "Stock out"}</span><span className="block break-all text-lg font-extrabold tabular-nums">{Number(totals[key].toFixed(3)).toLocaleString()}<span className="ml-1 text-xs font-medium">{metric === "movements" ? "entries" : metric}</span></span></span>
    </Button>)}</div>
    <div className="mt-4 h-56 min-w-0" data-testid="stock-trend-chart">
      <ResponsiveContainer width="100%" height="100%">
        {mode === "area" ? <AreaChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
          <defs>{(["stockIn", "stockOut"] as const).map((key) => <linearGradient key={key} id={`${id}-${key}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={key === "stockIn" ? "var(--success)" : "var(--destructive)"} stopOpacity={0.22} /><stop offset="100%" stopColor={key === "stockIn" ? "var(--success)" : "var(--destructive)"} stopOpacity={0.01} /></linearGradient>)}</defs>{axes}
          {visible.stockIn && <Area dot={data.length === 1 ? { r: 4 } : false} name="Stock in" type="monotone" dataKey="stockIn" stroke="var(--success)" fill={`url(#${id}-stockIn)`} strokeWidth={3} isAnimationActive={animate} animationDuration={650} />}
          {visible.stockOut && <Area dot={data.length === 1 ? { r: 4 } : false} name="Stock out" type="monotone" dataKey="stockOut" stroke="var(--destructive)" fill={`url(#${id}-stockOut)`} strokeWidth={3} isAnimationActive={animate} animationDuration={800} />}
        </AreaChart> : <BarChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>{axes}
          {visible.stockIn && <Bar name="Stock in" dataKey="stockIn" fill="var(--success)" radius={[4, 4, 0, 0]} isAnimationActive={animate} animationDuration={650} />}
          {visible.stockOut && <Bar name="Stock out" dataKey="stockOut" fill="var(--destructive)" radius={[4, 4, 0, 0]} isAnimationActive={animate} animationDuration={800} />}
        </BarChart>}
      </ResponsiveContainer>
    </div>
    {!totals.stockIn && !totals.stockOut && <p className="mt-1 text-center text-xs text-muted-foreground">No movements in this period</p>}
  </section>;
}