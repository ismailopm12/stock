<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Stock changes go through the `record_movement` database function so batch quantities and movement history stay in sync atomically.
- Signed-in pages live under `src/routes/_authenticated/`, which also renders the mobile bottom tab bar.
- Item creation helpers live in `src/lib/create-item.ts`; keep a created item ID during opening-stock retries to prevent duplicate products and report partial saves explicitly.
- Item photos live in the private `item-images` storage bucket under `<user_id>/`; `items.image_url` stores the object path and UI resolves it through the signed-URL helpers in `src/lib/item-image.ts` (public buckets are blocked by workspace policy).
- Standalone screens for an item (e.g. editing) are sibling routes like `inventory.edit.$id.tsx`, not children of `inventory.$id.tsx` — the details page renders no `<Outlet />`, so a child route would never display.
- The authenticated shell owns shared page motion, desktop navigation and mobile tabs so every inventory screen has consistent navigation without duplicating layouts.
- StockSheet validates unit-aware quantities and available batch stock through the shared stock-validation helper before calling the atomic database function.
- Movement reads paginate to completion by default so history exports and reports do not silently truncate older records.
- Item report filtering, inclusive local-calendar date boundaries, aggregation and CSV rows share the browser-safe item-report helper so displayed results and downloads stay consistent.
- Stale module recovery is shared by preload events, unhandled rejections, router catch handlers and an eagerly imported PageLoadError fallback with a time-bounded reload guard; repeated failures show a reload control rather than re-reporting an already handled chunk error.
- Decimal stock and minimum thresholds use additive precision columns; inventory queries map them into the shared domain quantities, and record_movement remains the atomic mutation boundary with unit-aware validation.
- Unit normalization and precision rules live in item-units; reusable user-owned categories are saved separately from item labels so empty categories remain selectable.
- Interactive stock trends use the browser-safe stock-trend helper and shared StockTrend view; default to movement counts or a selected unit to avoid adding incompatible units, and disable chart animation for reduced motion.
- Inventory status filters are validated URL search state so dashboard health shortcuts open the matching inventory view.

- Professional content headers use the shared PageHeader optional icon; mobile navigation stays shell-owned in a single-row dock that lists every tab in order (Profile last) with Button-as-Link controls and a filled icon surface marking the active tab.
- Item barcodes are auto-generated EAN-13 codes assigned by a database trigger (unique per user); scan sessions plan batch steps in the browser-safe scan-session helper and apply them only through record_movement.

- Android builds ship as a Capacitor shell kept outside the repository that loads the published site URL rather than bundling a static build, because the app is server-rendered and has no static page to package.
- Batch numbers are calendar days written day/month/year (e.g. 22/10/2026) by the shared batch-date helper and the BatchDateField picker, so every stock batch reads the same; displayed dates use the display-date helper while CSV exports keep ISO dates for spreadsheets.
- The app stays deployable off-platform: `vite.config.ts` switches the nitro preset to `vercel` only on Vercel, `vercel.json` pins build/install commands, `package.json` engines pins Node, and application flows use only publishable backend settings; generated privileged clients remain unused.
- Shared native surface and motion rules live in global CSS; shell data-tone attributes select semantic screen and navigation accents without changing stock or authentication logic.
