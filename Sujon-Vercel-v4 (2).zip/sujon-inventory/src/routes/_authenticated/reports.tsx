import { Button } from "@/components/ui/button";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Download, Package, Search, ChartNoAxesCombined, CalendarDays, ChevronRight } from "lucide-react";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { downloadCsv, itemsQuery, money, movementsQuery, stockStatus, totalQty } from "@/lib/inventory";
import { StockTrend, useChartMotion } from "@/components/app/StockTrend";
import { PageHeader } from "@/components/app/ui";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { buildItemReport, itemReportCsv, recentDateRange, reportBounds } from "@/lib/item-report";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({ meta: [{ title: "Reports — Sujon" }, { name: "description", content: "Inventory reports." }, { property: "og:title", content: "Reports — Sujon" }, { property: "og:description", content: "Inventory valuation and stock movement reports." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => Promise.all([context.queryClient.ensureQueryData(itemsQuery), context.queryClient.ensureQueryData(movementsQuery())]),
  component: Reports,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Reports() {
  const animate = useChartMotion();
  const { data: items } = useSuspenseQuery(itemsQuery);
  const { data: moves } = useSuspenseQuery(movementsQuery());
  const [range, setRange] = useState<number | null>(30);
  const [dates, setDates] = useState(() => recentDateRange(30));
  const [search, setSearch] = useState("");
  const [itemId, setItemId] = useState("");
  const bounds = reportBounds(dates.start, dates.end);
  const rows = buildItemReport(items, moves, { ...dates, search, itemId });
  const selectedIds = new Set(rows.map((row) => row.item.id));
  const rm = bounds ? moves.filter((m) => selectedIds.has(m.item_id) && new Date(m.created_at).getTime() >= bounds.start && new Date(m.created_at).getTime() < bounds.endExclusive) : [];
  const tin = rows.reduce((sum, row) => sum + row.stockIn, 0);
  const tout = rows.reduce((sum, row) => sum + row.stockOut, 0);
  const selectedItems = rows.map((row) => row.item);
  function preset(days: number) { setRange(days); setDates(recentDateRange(days)); }

  const cats: Record<string, number> = {};
  selectedItems.forEach((i) => { const k = i.category || "Other"; cats[k] = (cats[k] || 0) + totalQty(i) * Number(i.price); });
  const catData = Object.entries(cats).map(([name, value]) => ({ name, value })).filter((c) => c.value > 0);

  const outBy: Record<string, number> = {};
  rm.filter((m) => m.type === "out").forEach((m) => { const k = m.items?.name ?? "?"; outBy[k] = (outBy[k] || 0) + m.quantity; });
  const top = Object.entries(outBy).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, qty]) => ({ name: name.slice(0, 10), qty }));

  const status = { in: 0, low: 0, out: 0 };
  selectedItems.forEach((i) => status[stockStatus(i)]++);

  function exportReport() {
    if (!bounds) return;
    downloadCsv(`stock-report-${dates.start}-to-${dates.end}.csv`, itemReportCsv(rows, dates.start, dates.end));
  }

  return (
    <div>
      <PageHeader icon={ChartNoAxesCombined} title="Reports" subtitle="Inventory performance" action={
        <Button variant="native" disabled={!bounds || !rows.length} onClick={exportReport} className="h-11 rounded-xl border border-border px-3 text-sm font-semibold"><Download className="h-4 w-4" />CSV</Button>} />
      <div className="px-5">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-bold"><CalendarDays className="h-4 w-4 text-primary" />Reporting period</h2>
        <div className="grid grid-cols-4 gap-1 rounded-xl bg-muted p-1">
          {[1, 7, 30, 90].map((d) => <Button variant="ghost" key={d} aria-pressed={range === d} onClick={() => preset(d)} className={cn("rounded-xl px-1 py-2 text-xs font-semibold", range === d ? "bg-card shadow-soft" : "text-muted-foreground")}>{d === 1 ? "Today" : `${d} days`}</Button>)}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="min-w-0 space-y-2"><Label htmlFor="report-from">From</Label><Input id="report-from" type="date" value={dates.start} onChange={(e) => { setRange(null); setDates((prev) => ({ ...prev, start: e.target.value })); }} className="h-12 min-w-0 rounded-xl bg-card" /></div>
          <div className="min-w-0 space-y-2"><Label htmlFor="report-to">To</Label><Input id="report-to" type="date" value={dates.end} onChange={(e) => { setRange(null); setDates((prev) => ({ ...prev, end: e.target.value })); }} className="h-12 min-w-0 rounded-xl bg-card" /></div>
        </div>
        {!bounds && <p role="alert" className="mt-3 rounded-xl bg-danger-soft p-3 text-sm text-destructive">Choose valid dates. The end date must be on or after the start date.</p>}
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="relative"><Search className="absolute left-3 top-4 h-4 w-4 text-muted-foreground" /><Input aria-label="Search report items" placeholder="Search item name or SKU" value={search} onChange={(e) => setSearch(e.target.value)} className="h-12 rounded-xl bg-card pl-10" /></div>
          <select aria-label="Filter report item" value={itemId} onChange={(e) => setItemId(e.target.value)} className="h-12 min-w-0 rounded-xl border border-input bg-card px-3 text-sm"><option value="">All items</option>{[...items].sort((a, b) => a.name.localeCompare(b.name)).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select>
        </div>
        <div className="mt-4 flex items-center justify-between border-b border-border pb-3"><p className="text-sm font-semibold">{rows.length} items</p><Button variant="link" size="sm" onClick={() => { setSearch(""); setItemId(""); preset(30); }}>Reset filters</Button></div>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="report-metric rounded-xl bg-success-soft p-4"><p className="flex items-center gap-2 text-xs font-semibold text-success"><ArrowDownLeft className="h-4 w-4" />Units in</p><p className="mt-2 break-all text-2xl font-extrabold tabular-nums text-success">+{tin}</p></div>
          <div className="report-metric rounded-xl bg-danger-soft p-4"><p className="flex items-center gap-2 text-xs font-semibold text-destructive"><ArrowUpRight className="h-4 w-4" />Units out</p><p className="mt-2 break-all text-2xl font-extrabold tabular-nums text-destructive">−{tout}</p></div>
        </div>
        <div className="mt-4 grid grid-cols-3 divide-x divide-border border-y border-border py-4 text-center">
          <div><p className="text-xl font-extrabold text-success">{status.in}</p><p className="text-xs text-muted-foreground">In stock</p></div>
          <div><p className="text-xl font-extrabold text-warning">{status.low}</p><p className="text-xs text-muted-foreground">Low</p></div>
          <div><p className="text-xl font-extrabold text-destructive">{status.out}</p><p className="text-xs text-muted-foreground">Out</p></div>
        </div>

        <div className="-mx-5"><StockTrend moves={rm} dates={dates} /></div>
        <section className="mt-6 border-t border-border pt-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h2 className="font-bold">Item quantities</h2><span className="text-xs text-muted-foreground">Available now · In / out for selected dates</span></div>
          <div className="grid gap-3 lg:grid-cols-2">
            {bounds && rows.map((row) => <article key={row.item.id} aria-label={`Report for ${row.item.name}`} className="report-item rounded-xl border border-border bg-card p-4">
              <Link to="/inventory/$id" params={{ id: row.item.id }} className="flex items-center gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-soft text-accent-foreground"><Package className="h-5 w-5" /></span><div className="min-w-0 flex-1"><h3 className="break-words text-sm font-bold">{row.item.name}</h3><p className="text-xs text-muted-foreground">{row.item.sku || "No SKU"} · {row.item.unit}</p></div><ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" /></Link>
              <dl className="mt-4 grid grid-cols-3 gap-2 border-t border-border pt-3">
                <div className="min-w-0"><dt className="text-[11px] text-muted-foreground">Available now</dt><dd data-testid="available" className="mt-1 break-all text-lg font-extrabold tabular-nums">{row.available.toLocaleString()}</dd></div>
                <div className="min-w-0"><dt className="flex items-center gap-1 text-[11px] text-success"><ArrowDownLeft className="h-3 w-3" />Stock in</dt><dd data-testid="stock-in" className="mt-1 break-all text-lg font-extrabold tabular-nums text-success">{row.stockIn.toLocaleString()}</dd></div>
                <div className="min-w-0"><dt className="flex items-center gap-1 text-[11px] text-destructive"><ArrowUpRight className="h-3 w-3" />Stock out</dt><dd data-testid="stock-out" className="mt-1 break-all text-lg font-extrabold tabular-nums text-destructive">{row.stockOut.toLocaleString()}</dd></div>
              </dl>
            </article>)}
            {bounds && !rows.length && <p className="py-8 text-center text-sm text-muted-foreground">No items match these filters.</p>}
          </div>
          <Button disabled={!bounds || !rows.length} onClick={exportReport} variant="outline" className="mt-4 h-12 w-full rounded-xl"><Download />Download item report</Button>
        </section>
        <section className="mt-6 border-t border-border py-5">
          <h2 className="font-bold">Top moving items</h2>
          <div className="mt-2 h-44">
            {top.length ? (
              <ResponsiveContainer><BarChart data={top}><XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />
                <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ borderRadius: 12, border: "none" }} />
                <Bar isAnimationActive={animate} animationDuration={750} dataKey="qty" radius={[10, 10, 10, 10]}>{top.map((_, k) => <Cell key={k} fill={COLORS[k % 5]} />)}</Bar></BarChart></ResponsiveContainer>
            ) : <p className="pt-14 text-center text-sm text-muted-foreground">No stock out in this period</p>}
          </div>
        </section>

        <section className="mt-6 border-t border-border py-5">
          <h2 className="font-bold">Value by category</h2>
          {catData.length ? (
            <div className="mt-2 grid grid-cols-[120px_minmax(0,1fr)] items-center gap-3">
              <div className="h-32"><ResponsiveContainer><PieChart><Pie isAnimationActive={animate} animationDuration={850} data={catData} dataKey="value" innerRadius={34} outerRadius={56} paddingAngle={3}>
                {catData.map((_, k) => <Cell key={k} fill={COLORS[k % 5]} />)}</Pie></PieChart></ResponsiveContainer></div>
              <div className="min-w-0 space-y-1.5">
                {catData.map((c, k) => (
                  <div key={c.name} className="flex items-center gap-2 text-sm"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: COLORS[k % 5] }} />
                    <span className="min-w-0 flex-1 truncate">{c.name}</span><span className="shrink-0 font-semibold">{money(c.value)}</span></div>
                ))}
              </div>
            </div>
          ) : <p className="py-6 text-center text-sm text-muted-foreground">No stock value yet</p>}
        </section>
      </div>
    </div>
  );
}
