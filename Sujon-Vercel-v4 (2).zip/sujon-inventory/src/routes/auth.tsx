import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Boxes, CheckCircle2, Eye, EyeOff, KeyRound, LoaderCircle, Lock, Mail, ShieldCheck, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Mode = "login" | "register" | "forgot";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { mode?: Mode } =>
    s["mode"] === "register" || s["mode"] === "forgot" ? { mode: s["mode"] } : {},
  head: () => ({
    meta: [
      { title: "Sign in — Sujon" },
      { name: "description", content: "Log in, register or reset your Sujon inventory account password." },
      { property: "og:title", content: "Sign in — Sujon" },
      { property: "og:description", content: "Log in or register to manage your inventory." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function friendly(msg: string) {
  const m = msg.toLowerCase();
  if (m.includes("invalid login")) return "Email or password is incorrect.";
  if (m.includes("email not confirmed")) return "Please confirm your email first — check your inbox.";
  if (m.includes("already registered")) return "This email already has an account. Try logging in.";
  if (m.includes("rate limit")) return "Too many attempts. Please wait a minute and try again.";
  if (m.includes("weak") || m.includes("pwned")) return "This password is too weak or known to be leaked. Choose a stronger one.";
  return msg;
}

function strength(pw: string) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

function AuthPage() {
  const { mode: initial = "login" } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(initial);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<null | "confirm" | "reset">(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) navigate({ to: "/dashboard", replace: true }); });
    const { data } = supabase.auth.onAuthStateChange((e, s) => {
      if (s && e !== "PASSWORD_RECOVERY") navigate({ to: "/dashboard", replace: true });
    });
    return () => data.subscription.unsubscribe();
  }, [navigate]);

  function switchMode(m: Mode) { setMode(m); setSent(null); setPassword(""); setConfirm(""); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    const cleanEmail = email.trim().toLowerCase();
    if (mode === "register" && password !== confirm) { toast.error("Passwords don't match"); return; }
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email: cleanEmail, password });
        if (error) throw error;
        toast.success("Welcome back!");
      } else if (mode === "register") {
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail, password,
          options: { emailRedirectTo: window.location.origin + "/auth", data: { full_name: name.trim() } },
        });
        if (error) throw error;
        if (data.user && data.user.identities?.length === 0) throw new Error("User already registered");
        if (!data.session) setSent("confirm");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, { redirectTo: window.location.origin + "/reset-password" });
        if (error) throw error;
        setSent("reset");
      }
    } catch (err) {
      toast.error(friendly(err instanceof Error ? err.message : "Something went wrong"));
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) toast.error(friendly(r.error.message));
  }

  const st = strength(password);
  const title = mode === "login" ? "Welcome back" : mode === "register" ? "Create your account" : "Reset your password";
  const sub = mode === "login" ? "Sign in to manage your stock, batches and reports."
    : mode === "register" ? "Start tracking inventory in minutes — free."
    : "Enter your email and we'll send you a secure reset link.";

  return (
    <div className="auth-page native-page mx-auto flex min-h-dvh max-w-lg flex-col px-6 pt-10 pb-8">
      <div className="auth-heading border-b border-border pb-6">
        <div className="mb-6 flex items-center gap-2 text-lg font-extrabold"><Boxes className="h-5 w-5 text-primary" />Sujon</div>
        <div className="animated-icon grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary">
          {mode === "forgot" ? <KeyRound className="h-7 w-7" /> : <Boxes className="h-7 w-7" />}
        </div>
        <h1 className="mt-5 text-2xl font-extrabold">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
        <div className="mt-4 flex gap-3 text-xs font-medium text-primary">
          <span className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5" />Secure</span>
          <span className="flex items-center gap-1"><Boxes className="h-3.5 w-3.5" />Batch control</span>
        </div>
      </div>

      {mode !== "forgot" ? (
        <div className="mt-6 grid grid-cols-2 gap-1 rounded-2xl bg-muted p-1">
          {(["login", "register"] as const).map((m) => (
            <Button variant="ghost" key={m} type="button" aria-pressed={mode === m} onClick={() => switchMode(m)}
              className={cn("rounded-xl py-2.5 text-sm font-semibold tap", mode === m ? "bg-card shadow-soft" : "text-muted-foreground")}>
              {m === "login" ? "Login" : "Register"}
            </Button>
          ))}
        </div>
      ) : (
        <Button variant="ghost" type="button" onClick={() => switchMode("login")} className="mt-4 self-start px-2 font-semibold">
          <ArrowLeft className="h-4 w-4" /> Back to login
        </Button>
      )}

      {sent ? (
        <div className="card-soft mt-6 p-6 text-center animate-in fade-in zoom-in-95">
          <CheckCircle2 className="icon-pop mx-auto h-12 w-12 text-primary" />
          <p className="mt-3 font-bold">Check your email</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {sent === "confirm" ? `We sent a confirmation link to ${email}. Open it to activate your account.`
              : `If an account exists for ${email}, a password reset link is on its way.`}
          </p>
          <Button variant="outline" className="mt-4 rounded-2xl" onClick={() => switchMode("login")}>Back to login</Button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "register" && (
            <Field id="auth-name" label="Full name" icon={UserRound}>
              <Input id="auth-name" required autoComplete="name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} className="h-12 rounded-2xl bg-card pl-11" />
            </Field>
          )}
          <Field id="auth-email" label="Email" icon={Mail}>
            <Input id="auth-email" required type="email" autoComplete="email" inputMode="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-12 rounded-2xl bg-card pl-11" />
          </Field>
          {mode !== "forgot" && (
            <Field id="auth-password" label="Password" icon={Lock}>
              <Input id="auth-password" required minLength={mode === "register" ? 8 : 6} type={show ? "text" : "password"}
                autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder="••••••••"
                value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 rounded-2xl bg-card pl-11 pr-12" />
              <Button type="button" variant="ghost" size="icon" aria-label={show ? "Hide password" : "Show password"} onClick={() => setShow(!show)}
                className="absolute right-1 top-1/2 h-10 w-10 -translate-y-1/2 rounded-xl text-muted-foreground">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </Field>
          )}
          {mode === "register" && (
            <>
              <div className="flex gap-1" aria-label={`Password strength ${st} of 4`}>
                {[0, 1, 2, 3].map((i) => (
                  <div key={i} className={cn("h-1.5 flex-1 rounded-full transition-colors", i < st ? (st >= 3 ? "bg-success" : st === 2 ? "bg-warning" : "bg-destructive") : "bg-muted")} />
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Use 8+ characters with upper & lower case, a number and a symbol.</p>
              <Field id="auth-confirm" label="Confirm password" icon={Lock}>
                <Input id="auth-confirm" required type={show ? "text" : "password"} autoComplete="new-password" placeholder="••••••••"
                  value={confirm} onChange={(e) => setConfirm(e.target.value)}
                  aria-invalid={confirm.length > 0 && confirm !== password}
                  className="h-12 rounded-2xl bg-card pl-11 aria-[invalid=true]:border-destructive" />
              </Field>
            </>
          )}
          {mode === "login" && (
            <div className="flex justify-end">
              <Button variant="link" type="button" onClick={() => switchMode("forgot")} className="h-auto p-0 text-sm font-semibold">Forgot password?</Button>
            </div>
          )}
          <Button disabled={busy} className="h-12 w-full rounded-2xl text-base font-semibold shadow-glow">
            {busy && <LoaderCircle className="h-4 w-4 animate-spin" />}
            {busy ? "Please wait…" : mode === "login" ? "Login" : mode === "register" ? "Create account" : "Send reset link"}
          </Button>
        </form>
      )}

      {mode !== "forgot" && (
        <>
          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground"><div className="h-px flex-1 bg-border" />OR<div className="h-px flex-1 bg-border" /></div>
          <Button variant="outline" type="button" onClick={google} className="h-12 rounded-2xl bg-card font-semibold">
            <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden><path fill="currentColor" d="M21.35 11.1H12v2.9h5.35c-.23 1.5-1.7 4.4-5.35 4.4-3.22 0-5.85-2.67-5.85-5.95S8.78 6.5 12 6.5c1.83 0 3.06.78 3.76 1.45l2.57-2.47C16.68 3.94 14.55 3 12 3 6.98 3 3 7.03 3 12s3.98 9 9 9c5.2 0 8.64-3.65 8.64-8.8 0-.6-.07-1.05-.29-1.1Z"/></svg>
            Continue with Google
          </Button>
        </>
      )}

      <p className="mt-8 text-center text-xs font-medium text-muted-foreground">Development by Sujon</p>
    </div>
  );
}

function Field({ id, label, icon: Icon, children }: { id: string; label: string; icon: React.ComponentType<{ className?: string }>; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="font-semibold">{label}</Label>
      <div className="relative">
        <Icon className="pointer-events-none absolute left-4 top-1/2 z-10 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        {children}
      </div>
    </div>
  );
}
