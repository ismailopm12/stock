import type { Movement } from "./inventory";

export function stockTrend(moves: Movement[], start: string, end: string, metric: string) {
  const first = new Date(`${start}T00:00:00`);
  const last = new Date(`${end}T00:00:00`);
  if (!Number.isFinite(first.getTime()) || !Number.isFinite(last.getTime()) || first > last) return [];
  const dates: Date[] = [];
  for (const day = new Date(first); day <= last; day.setDate(day.getDate() + 1)) dates.push(new Date(day));
  const size = Math.max(1, Math.ceil(dates.length / 31));
  const buckets = dates.filter((_, index) => index % size === 0).map((date, index) => {
    const next = new Date(dates[Math.min((index + 1) * size, dates.length - 1)] ?? last);
    if ((index + 1) * size >= dates.length) next.setDate(next.getDate() + 1);
    return { start: date.getTime(), end: next.getTime(), label: date.toLocaleDateString(undefined, { month: "short", day: "numeric" }), stockIn: 0, stockOut: 0 };
  });
  for (const move of moves) {
    if (move.type === "adjust" || (metric !== "movements" && move.items?.unit !== metric)) continue;
    const time = new Date(move.created_at).getTime();
    const bucket = buckets.find((entry) => time >= entry.start && time < entry.end);
    if (!bucket) continue;
    bucket[move.type === "in" ? "stockIn" : "stockOut"] += metric === "movements" ? 1 : move.quantity;
  }
  return buckets.map((bucket) => ({ ...bucket, stockIn: Number(bucket.stockIn.toFixed(3)), stockOut: Number(bucket.stockOut.toFixed(3)) }));
}