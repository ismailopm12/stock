ALTER TABLE public.items ADD COLUMN IF NOT EXISTS barcode text;
CREATE OR REPLACE FUNCTION public.gen_item_barcode() RETURNS text LANGUAGE plpgsql SET search_path TO 'public' AS $$
DECLARE s text; sum int := 0; i int;
BEGIN
  s := '2' || lpad((floor(random()*1e11))::bigint::text, 11, '0');
  FOR i IN 1..12 LOOP sum := sum + substr(s,i,1)::int * CASE WHEN i % 2 = 0 THEN 3 ELSE 1 END; END LOOP;
  RETURN s || ((10 - sum % 10) % 10)::text;
END $$;
CREATE OR REPLACE FUNCTION public.items_set_barcode() RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public' AS $$
BEGIN
  IF NEW.barcode IS NULL OR trim(NEW.barcode) = '' THEN
    LOOP
      NEW.barcode := public.gen_item_barcode();
      EXIT WHEN NOT EXISTS (SELECT 1 FROM public.items WHERE user_id = NEW.user_id AND barcode = NEW.barcode);
    END LOOP;
  ELSE NEW.barcode := trim(NEW.barcode);
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS items_barcode_trg ON public.items;
CREATE TRIGGER items_barcode_trg BEFORE INSERT OR UPDATE OF barcode ON public.items FOR EACH ROW EXECUTE FUNCTION public.items_set_barcode();
UPDATE public.items SET barcode = public.gen_item_barcode() WHERE barcode IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS items_user_barcode_uniq ON public.items(user_id, barcode);