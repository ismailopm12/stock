import { supabase } from "@/integrations/supabase/client";
import { recordMovement } from "@/lib/inventory";
import { normalizeUnit, parseQuantity, validateQuantity } from "@/lib/item-units";

export type ItemDraft = {
  name: string; sku: string; category: string; unit: string; price: string;
  min_stock: string; qty: string; batch: string; expiry: string;
};

export function validateItem(draft: ItemDraft) {
  if (!draft.name.trim()) throw new Error("Enter a product name.");
  validateQuantity(draft.min_stock, draft.unit, "Minimum stock");
  validateQuantity(draft.qty, draft.unit, "Opening quantity");
  for (const [label, value, integer] of [["Unit price", draft.price, false]] as const) {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0 || (integer && !Number.isInteger(n))) {
      throw new Error(`${label} must be a non-negative ${integer ? "whole number" : "number"}.`);
    }
  }
  if (parseQuantity(draft.qty, draft.unit) > 0 && !draft.batch.trim()) throw new Error("Enter a batch number for opening stock.");
}

export async function insertItem(draft: ItemDraft) {
  const { data, error } = await supabase.from("items").insert({
    name: draft.name.trim(), sku: draft.sku.trim() || null, category: draft.category.trim() || null,
    unit: normalizeUnit(draft.unit), price: Number(draft.price), min_stock: Math.trunc(parseQuantity(draft.min_stock, draft.unit)), min_stock_decimal: parseQuantity(draft.min_stock, draft.unit),
  }).select("id").single();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("The product could not be saved. Please try again.");
  return data.id;
}

export async function saveOpeningStock(id: string, draft: ItemDraft) {
  const qty = parseQuantity(draft.qty, draft.unit);
  if (!qty) return;
  await recordMovement({ item_id: id, batch_no: draft.batch.trim(), type: "in", qty, note: "Opening stock", expiry: draft.expiry || null });
}