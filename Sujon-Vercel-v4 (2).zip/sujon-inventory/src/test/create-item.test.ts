import { describe, expect, it, vi } from "vitest";
const { rpc, insert } = vi.hoisted(() => ({ rpc: vi.fn(), insert: vi.fn() }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { rpc, from: () => ({ insert }) } }));
import { insertItem, saveOpeningStock, validateItem, type ItemDraft } from "@/lib/create-item";
const draft: ItemDraft = { name: "Test item", sku: "", category: "", unit: "pcs", price: "3.50", min_stock: "5", qty: "12", batch: "B-TEST", expiry: "" };
describe("Item creation", () => {
  it("surfaces failed product saves", async () => {
    insert.mockReturnValue({ select: () => ({ single: async () => ({ data: null, error: { message: "Save failed" } }) }) });
    await expect(insertItem(draft)).rejects.toThrow("Save failed");
  });
  it("records opening stock through the atomic stock function", async () => {
    rpc.mockResolvedValue({ error: null });
    await saveOpeningStock("item-id", draft);
    expect(rpc).toHaveBeenCalledWith("record_movement", { _item_id: "item-id", _batch_no: "B-TEST", _type: "in", _amount: 12, _note: "Opening stock" });
  });
  it("does not swallow opening stock failures", async () => {
    rpc.mockResolvedValue({ error: new Error("Stock failed") });
    await expect(saveOpeningStock("item-id", draft)).rejects.toThrow("Stock failed");
  });
  it("rejects fractional stock instead of silently truncating it", () => {
    expect(() => validateItem({ ...draft, qty: "1.5" })).toThrow("whole number");
  });
});