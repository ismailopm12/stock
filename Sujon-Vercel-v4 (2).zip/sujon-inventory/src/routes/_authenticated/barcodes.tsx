import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Barcode as BarcodeIcon, Printer, ScanBarcode, Search } from "lucide-react";
import { itemsQuery, money } from "@/lib/inventory";
import { Barcode } from "@/components/app/Barcode";
import { PageHeader } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";

export const Route = createFileRoute("/_authenticated/barcodes")({
  head: () => ({ meta: [{ title: "Barcode labels — Sujon" }, { name: "description", content: "Print barcode labels for all your inventory items." }, { property: "og:title", content: "Barcode labels — Sujon" }, { property: "og:description", content: "Print auto-generated barcodes for every item." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(itemsQuery),
  component: BarcodesPage,
});

function BarcodesPage() {
  const { data: items } = useSuspenseQuery(itemsQuery);
  const [q, setQ] = useState("");
  const [copies, setCopies] = useState<Record<string, number>>(() => Object.fromEntries(items.map((i) => [i.id, 1])));
  const [showPrice, setShowPrice] = useState(true);
  const list = useMemo(() => items.filter((i) => `${i.name} ${i.sku ?? ""} ${i.barcode ?? ""}`.toLowerCase().includes(q.toLowerCase())), [items, q]);
  const labels = items.flatMap((i) => i.barcode ? Array.from({ length: copies[i.id] ?? 0 }, (_, n) => ({ i, n })) : []);

  return (
    <div className="pb-8">
      <div className="print:hidden">
        <PageHeader icon={BarcodeIcon} title="Barcode labels" subtitle={`${labels.length} labels ready`} action={<Button asChild variant="outline" size="sm" className="rounded-xl"><Link to="/scan"><ScanBarcode className="h-4 w-4" />Scan</Link></Button>} />
        <div className="space-y-3 px-5">
          <div className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input aria-label="Search items" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search items" className="h-11 rounded-xl bg-card pl-9" /></div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => setCopies(Object.fromEntries(items.map((i) => [i.id, 1])))}>All × 1</Button>
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => setCopies({})}>None</Button>
            <label className="ml-auto flex items-center gap-2 text-sm"><Checkbox checked={showPrice} onCheckedChange={(v) => setShowPrice(!!v)} />Show price</label>
          </div>
          <div className="divide-y divide-border rounded-2xl border border-border bg-card">
            {list.map((i) => (
              <div key={i.id} className="flex items-center gap-3 p-3">
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{i.name}</p><p className="font-mono text-xs text-muted-foreground">{i.barcode}</p></div>
                <label className="sr-only" htmlFor={`copies-${i.id}`}>Copies of {i.name}</label>
                <Input id={`copies-${i.id}`} type="number" min={0} max={200} value={copies[i.id] ?? 0}
                  onChange={(e) => setCopies((c) => ({ ...c, [i.id]: Math.max(0, Math.min(200, Math.floor(Number(e.target.value) || 0))) }))}
                  className="h-10 w-20 rounded-xl text-center" />
              </div>
            ))}
            {!list.length && <p className="p-6 text-center text-sm text-muted-foreground">No items found</p>}
          </div>
          <Button disabled={!labels.length} onClick={() => window.print()} className="h-12 w-full rounded-2xl text-base font-semibold shadow-glow"><Printer className="h-4 w-4" />Print {labels.length} labels</Button>
          <h2 className="pt-2 font-bold">Preview</h2>
        </div>
      </div>
      <div className="print-area grid grid-cols-2 gap-3 px-5 sm:grid-cols-3 print:grid-cols-3 print:gap-2 print:px-0">
        {labels.map(({ i, n }) => (
          <div key={`${i.id}-${n}`} className="label-card break-inside-avoid rounded-xl border border-border bg-card p-2 text-center">
            <p className="truncate text-xs font-bold">{i.name}</p>
            <Barcode value={i.barcode!} height={44} className="mx-auto h-auto w-full" />
            {showPrice && <p className="text-xs font-semibold">{money(Number(i.price))}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
