import { afterEach, describe, expect, it, vi } from "vitest";
import { isChunkLoadError } from "@/lib/chunk-recovery";

describe("Stale module recovery", () => {
  afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });
  it("recognizes Safari module failures caught by the page boundary", () => {
    expect(isChunkLoadError(new TypeError("Importing a module script failed."))).toBe(true);
  });
  it("recognizes Chromium and Firefox module failures", () => {
    expect(isChunkLoadError(new TypeError("Failed to fetch dynamically imported module: /assets/reports-old.js"))).toBe(true);
    expect(isChunkLoadError(new Error("error loading dynamically imported module"))).toBe(true);
  });
  it("does not reload for unrelated data errors", () => {
    expect(isChunkLoadError(new Error("Could not save item"))).toBe(false);
  });
  it("recognizes serialized and cross-frame errors", () => {
    expect(isChunkLoadError({ message: "Importing a module script failed." })).toBe(true);
    expect(isChunkLoadError({ message: "Permission denied" })).toBe(false);
  });
  it("reloads stale imports once and prevents a repeated failure loop", async () => {
    vi.resetModules();
    const reload = vi.fn();
    const storage = new Map<string, string>();
    vi.stubGlobal("window", { location: { reload }, sessionStorage: { getItem: (key: string) => storage.get(key), setItem: (key: string, value: string) => storage.set(key, value) } });
    const { recoverChunkLoad } = await import("@/lib/chunk-recovery");
    expect(recoverChunkLoad({ message: "Importing a module script failed." })).toBe(true);
    expect(recoverChunkLoad(new Error("Importing a module script failed."))).toBe(false);
    expect(reload).toHaveBeenCalledTimes(1);
  });
  it("allows a new recovery after the cooldown expires", async () => {
    vi.resetModules();
    const reload = vi.fn();
    vi.stubGlobal("window", { location: { reload }, sessionStorage: { getItem: () => String(Date.now() - 30_001), setItem: vi.fn() } });
    const { recoverChunkLoad } = await import("@/lib/chunk-recovery");
    expect(recoverChunkLoad(new Error("Importing a module script failed."))).toBe(true);
    expect(reload).toHaveBeenCalledTimes(1);
  });
});