export const itemUnits = [
  { value: "pcs", label: "Pieces (pcs)" }, { value: "kg", label: "Kilograms (kg)" },
  { value: "g", label: "Grams (g)" }, { value: "lb", label: "Pounds (lb)" },
  { value: "oz", label: "Ounces (oz)" }, { value: "l", label: "Litres (l)" },
  { value: "ml", label: "Millilitres (ml)" }, { value: "m", label: "Metres (m)" },
  { value: "cm", label: "Centimetres (cm)" }, { value: "box", label: "Boxes" },
  { value: "pack", label: "Packs" }, { value: "pair", label: "Pairs" },
  { value: "dozen", label: "Dozens" }, { value: "bottle", label: "Bottles" },
];
export function normalizeUnit(unit: string) {
  const value = unit.trim().toLowerCase();
  const aliases: Record<string, string> = { kilograms: "kg", kilogram: "kg", grams: "g", gram: "g", lbs: "lb", pounds: "lb", pound: "lb", pieces: "pcs", pc: "pcs", liters: "l", litres: "l", liter: "l", litre: "l", meter: "m", metre: "m" };
  return aliases[value] ?? (value || "pcs");
}
export const allowsFraction = (unit: string) => ["kg", "g", "lb", "oz", "l", "ml", "m", "cm"].includes(normalizeUnit(unit));

// Compound units: a major unit paired with its minor unit (1 major = 1000 or 100 minor).
const compoundUnits: Record<string, { minor: string[]; factor: number }> = {
  kg: { minor: ["g", "gm", "gms", "gram", "grams"], factor: 1000 },
  g: { minor: ["kg", "kilo", "kilos", "kilogram", "kilograms"], factor: 0.001 },
  l: { minor: ["ml", "millilitre", "millilitres", "milliliter", "milliliters"], factor: 1000 },
  ml: { minor: ["l", "lt", "litre", "litres", "liter", "liters"], factor: 0.001 },
  m: { minor: ["cm", "centimetre", "centimetres", "centimeter", "centimeters"], factor: 100 },
  cm: { minor: ["m", "metre", "metres", "meter", "meters"], factor: 0.01 },
};
export const supportsCompound = (unit: string) => normalizeUnit(unit) in compoundUnits;
export function quantityHint(unit: string) {
  const u = normalizeUnit(unit);
  const c = compoundUnits[u];
  if (!c) return null;
  const minor = c.minor[0];
  return `e.g. 12.5 or 12${u} 500${minor}`;
}

/**
 * Parses a quantity, accepting plain numbers ("12.5") and compound entries
 * like "12kg 500g" / "12kg500gm" / "1l 250ml" for units with a minor unit.
 * Returns the total in the item's unit. Throws on anything ambiguous.
 */
export function parseQuantity(value: string, unit: string) {
  const text = value.trim().toLowerCase();
  if (!text) return NaN;
  const plain = Number(text);
  if (Number.isFinite(plain)) return plain;
  const u = normalizeUnit(unit);
  const compound = compoundUnits[u];
  if (!compound) return NaN;
  const minorPattern = compound.minor.join("|");
  const majorPattern = u === "l" ? "l|lt|litre|litres|liter|liters" : u === "m" ? "m|metre|metres|meter|meters" : u === "g" ? "g|gm|gms|gram|grams" : `${u}|${u === "kg" ? "kilo|kilos|kilogram|kilograms" : u}`;
  const match = text.match(new RegExp(`^(\\d+(?:\\.\\d+)?)\\s*(?:${majorPattern})\\s*(\\d+(?:\\.\\d+)?)\\s*(?:${minorPattern})$`));
  if (!match) return NaN;
  return Number(match[1]) + Number(match[2]) / compound.factor;
}

export function validateQuantity(value: string, unit: string, label = "Quantity") {
  const quantity = parseQuantity(value, unit);
  if (!Number.isFinite(quantity) || quantity < 0 || quantity > 999999999) {
    const hint = quantityHint(unit);
    throw new Error(`${label} must be a non-negative number below one billion${hint ? ` (${hint})` : ""}.`);
  }
  if (!allowsFraction(unit) && !Number.isInteger(quantity)) throw new Error(`${label} must be a whole number for ${normalizeUnit(unit)}.`);
  if (Math.abs(quantity * 1000 - Math.round(quantity * 1000)) > 0.0001) throw new Error(`${label} supports up to 3 decimal places.`);
  return quantity;
}