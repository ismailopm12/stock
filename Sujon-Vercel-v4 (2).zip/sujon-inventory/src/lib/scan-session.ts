// Browser-safe planning for barcode scan sessions (stock in / out / audit).
export type PlanBatch = { batch_no: string; quantity: number; expiry_date: string | null; created_at: string };
export type PlanStep = { batch_no: string; type: "in" | "out" | "adjust"; qty: number };

const r3 = (n: number) => Math.round(n * 1000) / 1000;

/** Oldest-expiring first (FEFO), then oldest created. */
export function fefo(batches: PlanBatch[]) {
  return [...batches].sort((a, b) => {
    if (a.expiry_date && b.expiry_date && a.expiry_date !== b.expiry_date) return a.expiry_date.localeCompare(b.expiry_date);
    if (a.expiry_date && !b.expiry_date) return -1;
    if (!a.expiry_date && b.expiry_date) return 1;
    return a.created_at.localeCompare(b.created_at);
  });
}

/** Split a stock-out across batches FEFO. Throws when not enough stock. */
export function planOut(batches: PlanBatch[], qty: number): PlanStep[] {
  let left = r3(qty);
  const steps: PlanStep[] = [];
  for (const b of fefo(batches)) {
    if (left <= 0) break;
    if (b.quantity <= 0) continue;
    const take = r3(Math.min(b.quantity, left));
    steps.push({ batch_no: b.batch_no, type: "out", qty: take });
    left = r3(left - take);
  }
  if (left > 0) throw new Error(`Not enough stock (short by ${left})`);
  return steps;
}

/** Bring total stock to the counted amount. Shortages come off FEFO; extras go to the newest batch (or a new one). */
export function planAudit(batches: PlanBatch[], counted: number, newBatchNo: string): PlanStep[] {
  const total = r3(batches.reduce((s, b) => s + b.quantity, 0));
  const diff = r3(counted - total);
  if (diff === 0) return [];
  if (diff > 0) {
    const newest = [...batches].sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
    return newest ? [{ batch_no: newest.batch_no, type: "adjust", qty: r3(newest.quantity + diff) }] : [{ batch_no: newBatchNo, type: "in", qty: diff }];
  }
  let short = -diff;
  const steps: PlanStep[] = [];
  for (const b of fefo(batches)) {
    if (short <= 0) break;
    if (b.quantity <= 0) continue;
    const cut = r3(Math.min(b.quantity, short));
    steps.push({ batch_no: b.batch_no, type: "adjust", qty: r3(b.quantity - cut) });
    short = r3(short - cut);
  }
  return steps;
}

/** EAN-13 check digit validation (auto-generated codes are EAN-13). */
export function isEan13(code: string) {
  if (!/^\d{13}$/.test(code)) return false;
  const sum = [...code.slice(0, 12)].reduce((s, d, i) => s + Number(d) * (i % 2 ? 3 : 1), 0);
  return (10 - (sum % 10)) % 10 === Number(code[12]);
}
