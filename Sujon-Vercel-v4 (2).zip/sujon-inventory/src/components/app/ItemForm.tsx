import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AlertCircle, ArrowLeft, CalendarDays, Check, DollarSign, Hash, ImagePlus, Info, Layers3, LoaderCircle, Package, PackagePlus, Pencil, Save, Sparkles, Tag, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { BatchDateField } from "@/components/app/BatchDateField";
import { validateItem, type ItemDraft } from "@/lib/create-item";
import { useItemImage } from "@/lib/item-image";
import { cn } from "@/lib/utils";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { categoriesQuery, createCategory } from "@/lib/categories";
import { itemUnits, normalizeUnit, quantityHint } from "@/lib/item-units";

export type ItemImageSelection = { file: File | null; remove: boolean };

type Props = {
  mode: "new" | "edit";
  initial: ItemDraft;
  initialImagePath?: string | null;
  backTo: string;
  onSubmit: (draft: ItemDraft, image: ItemImageSelection) => Promise<void>;
};

export function ItemForm({ mode, initial, initialImagePath = null, backTo, onSubmit }: Props) {
  const [f, setF] = useState<ItemDraft>(initial);
  const { data: categories = [] } = useQuery(categoriesQuery);
  const qc = useQueryClient();
  const [addingCategory, setAddingCategory] = useState(false);
  const [newCategory, setNewCategory] = useState("");
  const [categoryBusy, setCategoryBusy] = useState(false);
  const categoryOptions = [...new Set([...categories.map((c) => c.name), ...(f.category ? [f.category] : [])])].sort();
  async function addCategory() {
    if (categoryBusy) return;
    setCategoryBusy(true);
    try {
      const name = await createCategory(newCategory);
      await qc.invalidateQueries({ queryKey: categoriesQuery.queryKey });
      setF((prev) => ({ ...prev, category: name }));
      setAddingCategory(false); setNewCategory(""); toast.success("Category created");
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not create category."); }
    finally { setCategoryBusy(false); }
  }
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [image, setImage] = useState<ItemImageSelection>({ file: null, remove: false });
  const [preview, setPreview] = useState<string | null>(null);
  const submitting = useRef(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const existingUrl = useItemImage(image.remove ? null : initialImagePath);
  const shownImage = image.file ? preview : existingUrl;

  const set = (k: keyof ItemDraft) => (e: React.ChangeEvent<HTMLInputElement>) => setF((prev) => ({ ...prev, [k]: e.target.value }));

  function pickImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Choose an image file."); return; }
    if (preview) URL.revokeObjectURL(preview);
    setPreview(URL.createObjectURL(file));
    setImage({ file, remove: false });
  }

  function clearImage() {
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    setImage({ file: null, remove: true });
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (submitting.current) return;
    try { validateItem(f); } catch (err) { setError(err instanceof Error ? err.message : "Check the item details."); return; }
    submitting.current = true;
    setBusy(true); setError("");
    try {
      await onSubmit(f, image);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Please try again.");
    } finally { submitting.current = false; setBusy(false); }
  }

  const field = (k: keyof ItemDraft, label: string, icon?: React.ReactNode, props: React.ComponentProps<typeof Input> = {}) => (
    <div className="min-w-0 space-y-2">
      <Label htmlFor={`item-${k}`} className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">{icon}{label}</Label>
      <Input
        id={`item-${k}`}
        value={f[k]}
        onChange={set(k)}
        disabled={busy}
        className="h-13 min-w-0 rounded-2xl border-transparent bg-muted/70 px-4 text-base font-medium shadow-none transition-all placeholder:font-normal placeholder:text-muted-foreground/70 focus-visible:border-primary/40 focus-visible:bg-card focus-visible:ring-4 focus-visible:ring-primary/15"
        {...props}
      />
    </div>
  );

  const step = (n: number, title: string, hint: string, tone: string, children: React.ReactNode, delay: number) => (
    <section className="item-enter space-y-4 border-t border-border py-5" style={{ animationDelay: `${delay}ms` }}>
      <div className="flex items-center gap-3">
        <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-xl text-sm font-extrabold", tone)}>{n}</span>
        <div className="min-w-0">
          <h2 className="text-sm font-bold">{title}</h2>
          <p className="text-xs text-muted-foreground">{hint}</p>
        </div>
      </div>
      {children}
    </section>
  );

  return (
    <div className="px-5 pt-5">
      <header className="item-enter mb-5 flex items-center gap-3">
        <Button asChild variant="outline" size="icon" className="h-10 w-10 shrink-0 rounded-full bg-card"><Link to={backTo} aria-label="Back"><Package className="hidden" /><ArrowLeftIcon /></Link></Button>
        <div><p className="text-xs font-medium text-muted-foreground">Inventory</p><h1 className="text-xl font-extrabold">{mode === "new" ? "Add item" : "Edit item"}</h1></div>
      </header>

      <div className="item-enter relative mb-6 overflow-hidden rounded-3xl bg-gradient-primary p-5 text-primary-foreground shadow-glow" style={{ animationDelay: "60ms" }}>
        <Sparkles className="absolute -right-3 -top-3 h-24 w-24 opacity-15" />
        <div className="flex items-center gap-4">
          <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-2xl bg-overlay-soft backdrop-blur-sm">
            {shownImage ? <img src={shownImage} alt="" className="h-full w-full object-cover" /> : mode === "new" ? <PackagePlus className="h-7 w-7" /> : <Pencil className="h-6 w-6" />}
          </div>
          <div className="min-w-0">
            <h2 className="break-words text-lg font-extrabold">{f.name || (mode === "new" ? "New inventory item" : "Edit item")}</h2>
            <p className="mt-0.5 text-xs font-medium opacity-85">{f.category || (mode === "new" ? "Product details & opening stock" : "Update product details")}</p>
          </div>
        </div>
      </div>

      <form onSubmit={save} className="space-y-4">
        {step(1, "Item information", "Name, photo and pricing", "bg-primary-soft text-accent-foreground", (
          <>
            <div className="flex items-center gap-4">
              <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-2xl border-2 border-dashed border-primary/30 bg-primary-soft/50 text-accent-foreground">
                {shownImage ? <img src={shownImage} alt="Item photo preview" className="h-full w-full object-cover" /> : <ImagePlus className="h-7 w-7" />}
              </div>
              <div className="min-w-0 flex-1 space-y-2">
                <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Item photo</p>
                <div className="flex flex-wrap gap-2">
                  <Button type="button" variant="outline" size="sm" disabled={busy} onClick={() => fileRef.current?.click()} className="tap rounded-xl bg-primary-soft text-accent-foreground hover:bg-primary-soft/80">
                    <ImagePlus />{shownImage ? "Change photo" : "Add photo"}
                  </Button>
                  {shownImage && (
                    <Button type="button" variant="ghost" size="sm" disabled={busy} onClick={clearImage} className="tap rounded-xl text-destructive hover:bg-danger-soft">
                      <Trash2 />Remove
                    </Button>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground">Shown on the item and in the list.</p>
              </div>
              <input ref={fileRef} type="file" accept="image/*" onChange={pickImage} className="hidden" aria-label="Choose item photo" />
            </div>
            {field("name", "Product name *", <Package className="h-3.5 w-3.5" />, { required: true, placeholder: "e.g. Wireless keyboard", autoComplete: "off" })}
            <div className="grid grid-cols-2 gap-3">
              {field("sku", "SKU", <Hash className="h-3.5 w-3.5" />, { placeholder: "e.g. KB-001" })}
              <div className="min-w-0 space-y-2">
                <Label htmlFor="item-category" className="flex items-center gap-1.5 text-[11px] font-bold uppercase text-muted-foreground"><Tag className="h-3.5 w-3.5" />Category</Label>
                <select id="item-category" disabled={busy} value={f.category} onChange={(e) => setF((prev) => ({ ...prev, category: e.target.value }))} className="h-13 w-full min-w-0 rounded-2xl border border-input bg-muted/70 px-3 text-sm"><option value="">Uncategorized</option>{categoryOptions.map((name) => <option key={name} value={name}>{name}</option>)}</select>
                <Button type="button" variant="link" size="sm" disabled={busy} onClick={() => setAddingCategory((prev) => !prev)} className="h-7 px-0"><Tag className="h-3 w-3" />Create category</Button>
              </div>
            </div>
            {addingCategory && <div className="space-y-2 border-t border-border pt-3">
              <Label htmlFor="new-category">New category name</Label>
              <div className="flex gap-2"><Input id="new-category" autoFocus disabled={categoryBusy} value={newCategory} onChange={(e) => setNewCategory(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void addCategory(); } }} placeholder="e.g. Fresh produce" className="h-11 min-w-0 flex-1 rounded-xl" /><Button type="button" disabled={categoryBusy || !newCategory.trim()} onClick={addCategory} className="h-11 rounded-xl">{categoryBusy ? <LoaderCircle className="animate-spin" /> : <Check />}Add</Button><Button type="button" variant="ghost" size="icon" aria-label="Cancel category creation" onClick={() => setAddingCategory(false)}><Trash2 /></Button></div>
            </div>}
            <div className="grid grid-cols-2 gap-3">
              <div className="min-w-0 space-y-2"><Label htmlFor="item-unit" className="flex items-center gap-1.5 text-[11px] font-bold uppercase text-muted-foreground"><Layers3 className="h-3.5 w-3.5" />Unit</Label><select id="item-unit" value={normalizeUnit(f.unit)} disabled={busy} onChange={(e) => setF((prev) => ({ ...prev, unit: e.target.value }))} className="h-13 w-full min-w-0 rounded-2xl border border-input bg-muted/70 px-3 text-sm">{!itemUnits.some((u) => u.value === normalizeUnit(f.unit)) && <option value={normalizeUnit(f.unit)}>{f.unit}</option>}{itemUnits.map((u) => <option key={u.value} value={u.value}>{u.label}</option>)}</select></div>
              {field("price", "Unit price (USD)", <DollarSign className="h-3.5 w-3.5" />, { type: "number", min: 0, step: "0.01", inputMode: "decimal", placeholder: "0.00" })}
            </div>
            {field("min_stock", `Minimum stock alert (${normalizeUnit(f.unit)})`, <Info className="h-3.5 w-3.5" />, { type: "text", inputMode: "decimal", autoComplete: "off", placeholder: quantityHint(f.unit) ?? "0" })}
          </>
        ), 120)}

        {mode === "new" && step(2, "Opening stock", "Optional first batch", "bg-mint-soft text-mint", (
          <>
            {field("qty", `Quantity (${normalizeUnit(f.unit)})`, <Layers3 className="h-3.5 w-3.5" />, { type: "text", inputMode: "decimal", autoComplete: "off", placeholder: quantityHint(f.unit) ?? "0" })}
            <BatchDateField id="item-batch" disabled={busy} value={f.batch} onChange={(v) => setF((prev) => ({ ...prev, batch: v }))}
              label="Batch date" />
            {field("expiry", "Expiry date", <CalendarDays className="h-3.5 w-3.5" />, { type: "date" })}
          </>
        ), 180)}

        {error && (
          <div role="alert" className="item-enter flex gap-2 rounded-2xl border border-destructive/20 bg-danger-soft p-3 text-sm text-destructive">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <p className="min-w-0">{error}</p>
          </div>
        )}

        <div className="item-enter space-y-3 pb-4 pt-1" style={{ animationDelay: "240ms" }}>
          <Button type="submit" disabled={busy} className="tap h-14 w-full rounded-2xl bg-gradient-primary text-base font-bold shadow-glow hover:opacity-95">
            {busy ? <LoaderCircle className="animate-spin" /> : mode === "new" ? <Save /> : <Check />}
            {busy ? "Saving item…" : mode === "new" ? "Save item" : "Save changes"}
          </Button>
          <Button asChild variant="ghost" className="h-10 w-full text-muted-foreground"><Link to={backTo}>Cancel</Link></Button>
        </div>
      </form>
    </div>
  );
}

function ArrowLeftIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left"><path d="m12 19-7-7 7-7" /><path d="M19 12H5" /></svg>
  );
}
