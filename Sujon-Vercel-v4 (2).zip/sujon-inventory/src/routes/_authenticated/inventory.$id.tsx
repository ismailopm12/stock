import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { dayMonthYear, dayMonthYearTime } from "@/lib/display-date";
import { Barcode } from "@/components/app/Barcode";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Copy, Printer, ScanBarcode, ArrowDownLeft, ArrowUpRight, ArrowLeft, CalendarDays, ChevronRight, Clock3, Layers3, LoaderCircle, Package, Pencil, Plus, SlidersHorizontal, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { daysUntil, itemsQuery, money, movementsQuery, stockStatus, totalQty } from "@/lib/inventory";
import { deleteItemImage, useItemImage } from "@/lib/item-image";
import { StockSheet } from "@/components/app/StockSheet";
import { StatusBadge } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/_authenticated/inventory/$id")({
  head: () => ({ meta: [
    { title: "Item details — Sujon" }, { name: "description", content: "Inventory item details, batches, expiry dates and movement history." },
    { property: "og:title", content: "Item details — Sujon" }, { property: "og:description", content: "Inventory item details, batches, expiry dates and movement history." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  loader: ({ context }) => Promise.all([context.queryClient.ensureQueryData(itemsQuery), context.queryClient.ensureQueryData(movementsQuery())]),
  component: Detail,
});

function Detail() {
  const { id } = Route.useParams();
  const { data: items } = useSuspenseQuery(itemsQuery);
  const { data: moves } = useSuspenseQuery(movementsQuery());
  const [sheet, setSheet] = useState<{ mode: "in" | "out" | "adjust"; batch?: string } | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [zoom, setZoom] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const item = items.find((i) => i.id === id);
  const imageUrl = useItemImage(item?.image_url);
  if (!item) return <div className="px-5 py-10 text-center"><Package className="mx-auto mb-4 h-10 w-10 text-muted-foreground" /><h1 className="text-lg font-bold">Item not found</h1><Button asChild variant="link"><Link to="/inventory">Back to inventory</Link></Button></div>;
  const batches = [...item.batches].sort((a, b) => (a.expiry_date ?? "9").localeCompare(b.expiry_date ?? "9"));
  const hist = moves.filter((m) => m.item_id === id);
  const quantity = totalQty(item);
  const activeBatches = batches.filter((b) => b.quantity > 0).length;
  const imagePath = item.image_url;

  async function del() {
    if (deleting) return;
    setDeleting(true);
    try {
      const { error } = await supabase.from("items").delete().eq("id", id);
      if (error) throw error;
      try { await deleteItemImage(imagePath); }
      catch { toast.warning("Item deleted; photo cleanup could not finish."); }
      await qc.invalidateQueries();
      toast.success("Item deleted");
      await navigate({ to: "/inventory" });
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not delete item"); }
    finally { setDeleting(false); setDeleteOpen(false); }
  }

  return (
    <div className="item-enter px-5 pt-5">
      <header className="flex items-center justify-between">
        <Button asChild variant="outline" size="icon" className="h-10 w-10 rounded-full bg-card"><Link to="/inventory" aria-label="Back to inventory"><ArrowLeft /></Link></Button>
        <p className="text-sm font-semibold">Item details</p>
        <div className="flex items-center gap-1">
          <Button asChild variant="ghost" size="icon" aria-label="Edit item" title="Edit item" className="h-10 w-10 rounded-full text-muted-foreground hover:bg-primary-soft hover:text-accent-foreground"><Link to="/inventory/edit/$id" params={{ id }}><Pencil /></Link></Button>
          <Button onClick={() => setDeleteOpen(true)} variant="ghost" size="icon" aria-label="Delete item" title="Delete item" className="h-10 w-10 rounded-full text-muted-foreground hover:bg-danger-soft hover:text-destructive"><Trash2 /></Button>
        </div>
      </header>
      <section className="detail-overview mt-5 overflow-hidden rounded-3xl border border-border bg-card p-5 shadow-soft">
        <div className="flex items-start gap-4">
          {imageUrl ? (
            <Button variant="ghost" type="button" onClick={() => setZoom(true)} aria-label={`View photo of ${item.name}`} className="tap h-24 w-24 shrink-0 overflow-hidden rounded-2xl bg-muted p-0 ring-1 ring-border/60">
              <img src={imageUrl} alt={item.name} className="h-full w-full object-contain" />
            </Button>
          ) : (
            <div className="grid h-24 w-24 shrink-0 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow"><Package className="icon-pop h-9 w-9" /></div>
          )}
          <div className="min-w-0 flex-1">
            <span className="inline-block rounded-full bg-primary-soft px-2.5 py-0.5 text-[11px] font-semibold text-accent-foreground">{item.category || "Uncategorized"}</span>
            <h1 className="mt-2 break-words text-xl font-extrabold leading-tight sm:text-2xl">{item.name}</h1>
            <p className="mt-1 break-words text-xs text-muted-foreground">SKU · {item.sku || "Not assigned"}</p>
          </div>
        </div>
        <div className="mt-5 rounded-2xl bg-gradient-primary p-4 text-primary-foreground">
          <div className="flex items-center justify-between gap-2"><p className="text-[11px] font-semibold uppercase tracking-wide opacity-85">Available stock</p><StatusBadge s={stockStatus(item)} /></div>
          <div className="mt-1 flex flex-wrap items-baseline gap-2"><p className="item-number break-all text-4xl font-extrabold tabular-nums">{quantity.toLocaleString()}</p><span className="text-sm font-medium opacity-85">{item.unit}</span></div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[[money(quantity * Number(item.price)), "Stock value"], [money(Number(item.price)), "Unit price"], [`${item.min_stock} ${item.unit}`, "Min. stock"]].map(([v, l]) => (
            <div key={l} className="min-w-0 rounded-2xl bg-muted p-3"><p className="break-words text-sm font-bold tabular-nums">{v}</p><p className="mt-1 text-[11px] text-muted-foreground">{l}</p></div>
          ))}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <Button onClick={() => setSheet({ mode: "in" })} variant="stockIn" className="tap h-12 rounded-2xl font-semibold"><ArrowDownLeft />Stock In</Button>
          <Button onClick={() => setSheet({ mode: "out" })} disabled={quantity <= 0} variant="stockOut" className="tap h-12 rounded-2xl font-semibold"><ArrowUpRight />Stock Out</Button>
        </div>
      </section>
      {item.barcode && (
        <section className="mt-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
          <div className="flex items-center justify-between"><h2 className="flex items-center gap-2 text-sm font-bold"><ScanBarcode className="h-4 w-4 text-primary" />Barcode</h2>
            <Button variant="ghost" size="sm" className="rounded-xl" onClick={() => { void navigator.clipboard?.writeText(item.barcode!); toast.success("Barcode copied"); }}><Copy className="h-4 w-4" />Copy</Button></div>
          <div className="mt-2 rounded-2xl bg-background p-2"><Barcode value={item.barcode} height={56} className="mx-auto h-auto w-full max-w-72" /></div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button asChild variant="outline" className="rounded-xl"><Link to="/barcodes"><Printer className="h-4 w-4" />Print label</Link></Button>
            <Button asChild variant="outline" className="rounded-xl"><Link to="/scan"><ScanBarcode className="h-4 w-4" />Scan / audit</Link></Button>
          </div>
        </section>
      )}
      <Tabs defaultValue="batches" className="mt-5">
        <TabsList className="grid h-12 w-full grid-cols-2 rounded-xl bg-muted p-1">
          <TabsTrigger value="batches" className="gap-2 rounded-lg"><Layers3 className="h-4 w-4" />Batches <span className="text-xs text-muted-foreground">{batches.length}</span></TabsTrigger>
          <TabsTrigger value="activity" className="gap-2 rounded-lg"><Clock3 className="h-4 w-4" />Activity</TabsTrigger>
        </TabsList>
        <TabsContent value="batches" className="item-enter mt-5 space-y-3">
          <div className="flex items-center justify-between"><p className="text-xs font-medium text-muted-foreground">{activeBatches} active {activeBatches === 1 ? "batch" : "batches"}</p><Button variant="ghost" size="sm" onClick={() => setSheet({ mode: "in" })} className="text-accent-foreground"><Plus />Add batch</Button></div>
          {batches.map((b) => {
            const d = b.expiry_date ? daysUntil(b.expiry_date) : null;
            return <Button key={b.id} variant="outline" onClick={() => setSheet({ mode: "adjust", batch: b.batch_no })} className="tap h-auto w-full justify-start gap-3 whitespace-normal rounded-xl border-border bg-card p-4 text-left hover:bg-secondary">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-mint-soft text-mint"><Layers3 className="animated-icon" /></div>
              <div className="min-w-0 flex-1"><p className="break-all text-sm font-bold">{b.batch_no}</p><p className="mt-1 flex items-center gap-1 text-[11px] font-normal text-muted-foreground"><CalendarDays className="h-3 w-3" />{b.expiry_date ? dayMonthYear(b.expiry_date) : "No expiry date"}</p>{d !== null && d <= 30 && <p className={`mt-1 text-[11px] ${d < 0 ? "text-destructive" : "text-warning"}`}>{d < 0 ? "Expired" : `${d} days remaining`}</p>}</div>
              <div className="max-w-24 text-right"><p className="break-all font-bold tabular-nums">{b.quantity}</p><p className="break-all text-[11px] font-normal text-muted-foreground">{item.unit}</p></div><ChevronRight className="text-muted-foreground" />
            </Button>;
          })}
          {!batches.length && <div className="py-8 text-center"><Layers3 className="mx-auto h-9 w-9 text-muted-foreground" /><p className="mt-3 text-sm font-semibold">No batches yet</p><Button variant="link" onClick={() => setSheet({ mode: "in" })}>Add opening stock</Button></div>}
        </TabsContent>
        <TabsContent value="activity" className="item-enter mt-5">
          {hist.map((m) => {
            const Icon = m.type === "in" ? ArrowDownLeft : m.type === "out" ? ArrowUpRight : SlidersHorizontal;
            const tone = m.type === "in" ? "bg-success-soft text-success" : m.type === "out" ? "bg-danger-soft text-destructive" : "bg-primary-soft text-accent-foreground";
            return <div key={m.id} className="flex items-start gap-3 border-b border-border py-4">
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${tone}`}><Icon className="h-4 w-4" /></div>
              <div className="min-w-0 flex-1"><p className="text-sm font-semibold">{m.type === "adjust" ? "Stock adjustment" : m.type === "in" ? "Stock received" : "Stock removed"}</p><p className="mt-0.5 break-all text-xs text-muted-foreground">{m.batch_no}</p>{m.note && <p className="mt-1 break-words text-xs">{m.note}</p>}<p className="mt-1 text-[11px] text-muted-foreground">{dayMonthYearTime(m.created_at)}</p></div>
              <span className={`max-w-24 break-all text-right text-sm font-bold tabular-nums ${m.type === "in" ? "text-success" : m.type === "out" ? "text-destructive" : "text-accent-foreground"}`}>{m.type === "out" ? "−" : m.type === "in" ? "+" : "="}{m.quantity}</span>
            </div>;
          })}
          {!hist.length && <p className="py-10 text-center text-sm text-muted-foreground">No stock movements yet</p>}
        </TabsContent>
      </Tabs>
      <p className="mt-7 pb-4 text-center text-[11px] text-muted-foreground">Added {dayMonthYear(item.created_at)}</p>
      <StockSheet open={!!sheet} onOpenChange={(o) => !o && setSheet(null)} items={items} defaultItemId={id} defaultMode={sheet?.mode ?? "in"} defaultBatch={sheet?.batch ?? ""} />
      {zoom && imageUrl && (
        <div role="dialog" aria-label={`Photo of ${item.name}`} onClick={() => setZoom(false)} className="fixed inset-0 z-50 grid place-items-center bg-foreground/85 p-6">
          <img src={imageUrl} alt={item.name} className="item-enter max-h-full max-w-full rounded-2xl object-contain shadow-2xl" />
          <Button variant="native" size="icon" type="button" aria-label="Close photo" onClick={() => setZoom(false)} className="tap absolute right-5 top-5 h-11 w-11 rounded-full"><X /></Button>
        </div>
      )}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent className="max-w-sm rounded-2xl"><AlertDialogHeader><AlertDialogTitle>Delete this item?</AlertDialogTitle><AlertDialogDescription>This removes {item.name} and its batches. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel><AlertDialogAction disabled={deleting} onClick={(e) => { e.preventDefault(); void del(); }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{deleting && <LoaderCircle className="animate-spin" />}Delete item</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
