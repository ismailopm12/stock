import { createFileRoute, redirect, Outlet, Link, useRouterState } from "@tanstack/react-router";
import { BarChart3, Boxes, History, Home, ScanLine, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: Shell,
});

const tabs = [
  { to: "/dashboard", label: "Home", icon: Home, tone: "teal" },
  { to: "/inventory", label: "Items", icon: Boxes, tone: "sky" },
  { to: "/scan", label: "Scan", icon: ScanLine, tone: "violet" },
  { to: "/history", label: "History", icon: History, tone: "coral" },
  { to: "/reports", label: "Reports", icon: BarChart3, tone: "mint" },
  { to: "/profile", label: "Profile", icon: User, tone: "amber" },
] as const;

function Shell() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="app-shell mx-auto min-h-dvh max-w-6xl bg-background pb-28 md:grid md:grid-cols-[200px_minmax(0,1fr)] md:pb-8">
      <aside className="app-sidebar hidden border-r border-border px-4 pt-8 md:block">
        <Link to="/dashboard" className="mb-10 flex items-center gap-2 px-2 text-xl font-extrabold"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Boxes className="h-5 w-5" /></span>Sujon</Link>
        <nav aria-label="Main navigation" className="sticky top-6 space-y-2">
          {tabs.map((t) => <Button key={t.to} asChild variant="ghost" className={cn("h-12 w-full justify-start rounded-xl", path.startsWith(t.to) ? "bg-primary-soft text-accent-foreground" : "text-muted-foreground")}><Link to={t.to} data-tone={t.tone} aria-current={path.startsWith(t.to) ? "page" : undefined} className="native-tab"><t.icon />{t.label}</Link></Button>)}
        </nav>
      </aside>
      <main key={path} data-tone={tabs.find((t) => path.startsWith(t.to))?.tone ?? "teal"} className="app-main native-page min-w-0 md:px-5 md:pt-3"><Outlet /></main>
      <nav aria-label="Bottom navigation" className="bottom-nav-dock fixed inset-x-0 bottom-0 z-40 px-2 pb-safe md:hidden">
        <div className="bottom-nav-pill mx-auto grid max-w-lg grid-cols-6 gap-0.5 rounded-[1.75rem] px-1.5 py-1.5">
          {tabs.map((t) => {
            const active = path.startsWith(t.to);
            const quick = t.to === "/scan";
            return (
              <Button key={t.to} asChild variant="ghost" className={cn("bottom-tab native-tab tap h-14 min-w-0 flex-col gap-1 rounded-2xl px-0 py-1 text-[10px] font-semibold hover:bg-transparent", active ? "text-primary" : "text-muted-foreground")}>
                <Link to={t.to} data-tone={t.tone} aria-current={active ? "page" : undefined} className="min-w-0 flex-col">
                  <span className={cn("tab-symbol grid h-8 w-11 shrink-0 place-items-center rounded-full", active ? "bg-primary text-primary-foreground" : quick ? "bg-primary-soft text-primary" : "bg-transparent")}>
                    <t.icon className="h-[18px] w-[18px]" />
                  </span>
                  <span className="max-w-full truncate leading-none">{t.label}</span>
                </Link>
              </Button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
