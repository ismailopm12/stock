import { useEffect, useState } from "react";
import { dayMonthYear } from "@/lib/display-date";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowDownLeft, ArrowUpRight, SlidersHorizontal } from "lucide-react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { genBatchNo, recordMovement, type Item } from "@/lib/inventory";
import { validateStockQuantity } from "@/lib/stock-validation";
import { quantityHint } from "@/lib/item-units";
import { BatchDateField } from "@/components/app/BatchDateField";

type Mode = "in" | "out" | "adjust";

export function StockSheet({
  open, onOpenChange, items, defaultItemId, defaultMode = "in", defaultBatch,
}: {
  open: boolean; onOpenChange: (o: boolean) => void; items: Item[];
  defaultItemId?: string; defaultMode?: Mode; defaultBatch?: string;
}) {
  const qc = useQueryClient();
  const [mode, setMode] = useState<Mode>(defaultMode);
  const [itemId, setItemId] = useState(defaultItemId ?? "");
  const [batch, setBatch] = useState("");
  const [qty, setQty] = useState("");
  const [expiry, setExpiry] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setMode(defaultMode);
      setItemId(defaultItemId ?? items[0]?.id ?? "");
      setBatch(defaultBatch || (defaultMode === "in" ? genBatchNo() : ""));
      setQty(""); setExpiry(""); setNote("");
    }
  }, [open, defaultMode, defaultItemId, defaultBatch, items]);

  const item = items.find((i) => i.id === itemId);
  const batches = (item?.batches ?? []).filter((b) => mode === "adjust" || b.quantity > 0)
    .sort((a, b) => (a.expiry_date ?? "9").localeCompare(b.expiry_date ?? "9"));

  useEffect(() => {
    if (mode !== "in" && !batches.some((b) => b.batch_no === batch)) setBatch(batches[0]?.batch_no ?? "");
    if (mode === "in" && !batch) setBatch(genBatchNo());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, itemId]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (!itemId || !batch.trim() || (mode !== "in" && !batches.some((b) => b.batch_no === batch))) {
      toast.error("Fill item, batch and a valid quantity");
      return;
    }
    setBusy(true);
    try {
      const n = validateStockQuantity(qty, mode, batches.find((b) => b.batch_no === batch)?.quantity, item?.unit);
      await recordMovement({ item_id: itemId, batch_no: batch.trim(), type: mode, qty: n, note, expiry: expiry || null });
      toast.success(mode === "in" ? "Stock added" : mode === "out" ? "Stock removed" : "Stock adjusted");
      qc.invalidateQueries();
      onOpenChange(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed");
    } finally {
      setBusy(false);
    }
  }

  const modes: { k: Mode; label: string; icon: typeof ArrowDownLeft }[] = [
    { k: "in", label: "Stock In", icon: ArrowDownLeft },
    { k: "out", label: "Stock Out", icon: ArrowUpRight },
    { k: "adjust", label: "Adjust", icon: SlidersHorizontal },
  ];

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="mx-auto max-h-[90dvh] max-w-lg">
        <DrawerHeader><DrawerTitle>Stock movement</DrawerTitle></DrawerHeader>
        <form onSubmit={submit} className="space-y-4 overflow-y-auto px-4 pb-6">
          <div className="grid grid-cols-3 gap-2 rounded-2xl bg-muted p-1">
            {modes.map((m) => (
              <Button variant="ghost" type="button" key={m.k} aria-pressed={mode === m.k} disabled={busy} onClick={() => setMode(m.k)}
                className={cn("flex items-center justify-center gap-1.5 rounded-xl py-2 text-sm font-semibold tap",
                  mode === m.k ? "bg-card text-accent-foreground shadow-soft" : "text-muted-foreground")}>
                <m.icon className="h-4 w-4" />{m.label}
              </Button>
            ))}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="stock-item">Item</Label>
            <select id="stock-item" disabled={busy} value={itemId} onChange={(e) => setItemId(e.target.value)}
              className="h-11 w-full rounded-xl border border-input bg-card px-3 text-sm">
              {items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            {mode !== "in" && <Label htmlFor="stock-batch">Batch</Label>}
            {mode === "in" ? (
              <>
                <BatchDateField id="stock-batch" disabled={busy} value={batch} onChange={setBatch} />
                {!!item?.batches.length && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {item.batches.map((b) => (
                      <Button variant="ghost" disabled={busy} type="button" key={b.id} onClick={() => setBatch(b.batch_no)}
                        className="h-8 rounded-full bg-primary-soft px-2.5 py-1 text-xs font-medium text-accent-foreground">{b.batch_no}</Button>
                    ))}
                  </div>
                )}
              </>
            ) : batches.length ? (
              <select id="stock-batch" disabled={busy} value={batch} onChange={(e) => setBatch(e.target.value)}
                className="h-11 w-full rounded-xl border border-input bg-card px-3 text-sm">
                {batches.map((b) => (
                  <option key={b.id} value={b.batch_no}>
                    {b.batch_no} · {b.quantity} {item?.unit}{b.expiry_date ? ` · exp ${dayMonthYear(b.expiry_date)}` : ""}
                  </option>
                ))}
              </select>
            ) : <p className="rounded-xl bg-danger-soft p-3 text-sm text-destructive">No batches with stock for this item.</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="stock-qty">{mode === "adjust" ? "New quantity" : "Quantity"} ({item?.unit})</Label>
              <Input id="stock-qty" disabled={busy} inputMode="decimal" type="text" autoComplete="off" placeholder={quantityHint(item?.unit ?? "pcs") ?? "0"} value={qty} onChange={(e) => setQty(e.target.value)} className="h-11 rounded-xl" />
              {quantityHint(item?.unit ?? "pcs") && <p className="text-[11px] text-muted-foreground">{quantityHint(item?.unit ?? "pcs")}</p>}
            </div>
            {mode === "in" && (
              <div className="space-y-1.5">
                <Label>Expiry (optional)</Label>
                <Input type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} className="h-11 rounded-xl" />
              </div>
            )}
          </div>
          <div className="space-y-1.5">
            <Label>Note</Label>
            <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Supplier, order #, reason…" className="h-11 rounded-xl" />
          </div>
          <Button type="submit" disabled={busy || !item || (mode !== "in" && !batches.length)} className="h-12 w-full rounded-2xl text-base font-semibold shadow-glow">
            {busy ? "Saving…" : "Confirm"}
          </Button>
        </form>
      </DrawerContent>
    </Drawer>
  );
}
