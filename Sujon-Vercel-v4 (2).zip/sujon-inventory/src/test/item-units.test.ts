import { describe, expect, it } from "vitest";
import { itemUnits, normalizeUnit, parseQuantity, validateQuantity } from "@/lib/item-units";
import { validateStockQuantity } from "@/lib/stock-validation";
import { categoryName } from "@/lib/categories";
describe("Units and categories", () => {
  it("supports pcs, kilograms and pounds", () => {
    expect(itemUnits.map((u) => u.value)).toEqual(expect.arrayContaining(["pcs", "kg", "lb"]));
    expect(normalizeUnit("PCs")).toBe("pcs"); expect(normalizeUnit("kilograms")).toBe("kg");
  });
  it("retains exact fractional kg and lb quantities", () => {
    expect(validateStockQuantity("1.25", "in", undefined, "kg")).toBe(1.25);
    expect(validateStockQuantity("0.125", "out", 1.25, "lb")).toBe(0.125);
    expect(() => validateStockQuantity("1.251", "out", 1.25, "kg")).toThrow();
  });
  it("keeps pieces whole and rejects excess precision", () => {
    expect(() => validateQuantity("1.5", "pcs")).toThrow("whole number");
    expect(() => validateQuantity("1.2345", "kg")).toThrow("3 decimal");
  });
  it("creates non-empty trimmed categories", () => {
    expect(categoryName("  Fresh produce  ")).toBe("Fresh produce");
    expect(() => categoryName("  ")).toThrow();
  });
  it("calculates compound quantities like 12kg 500g", () => {
    expect(parseQuantity("12kg 500g", "kg")).toBe(12.5);
    expect(parseQuantity("12kg500gm", "kg")).toBe(12.5);
    expect(parseQuantity("12 kilo 500 grams", "kg")).toBe(12.5);
    expect(parseQuantity("1l 250ml", "l")).toBe(1.25);
    expect(parseQuantity("3m 50cm", "m")).toBe(3.5);
    expect(parseQuantity("500g 12kg", "g")).toBe(12500);
    expect(parseQuantity("12.5", "kg")).toBe(12.5);
  });
  it("rejects ambiguous or wrong-unit compound entries", () => {
    expect(parseQuantity("12 500", "kg")).toBeNaN();
    expect(parseQuantity("12kg 500", "kg")).toBeNaN();
    expect(parseQuantity("12kg 500g", "pcs")).toBeNaN();
    expect(parseQuantity("abc", "kg")).toBeNaN();
  });
  it("validates compound entries through stock validation", () => {
    expect(validateStockQuantity("12kg 500g", "in", undefined, "kg")).toBe(12.5);
    expect(validateStockQuantity("1l 250ml", "out", 2, "l")).toBe(1.25);
    expect(() => validateStockQuantity("12kg 500g", "out", 10, "kg")).toThrow("exceeds");
  });
});