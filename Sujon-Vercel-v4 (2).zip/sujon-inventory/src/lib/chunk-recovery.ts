const recoveryKey = "stockflow:chunk-recovery";
const retryWindowMs = 30_000;
let lastAttempt = 0;

export function isChunkLoadError(error: unknown): boolean {
  const message = typeof error === "object" && error !== null && "message" in error ? String(error.message) : String(error ?? "");
  return /importing a module script failed|failed to fetch dynamically imported module|error loading dynamically imported module|loading chunk .+ failed/i.test(message);
}

export function recoverChunkLoad(error: unknown): boolean {
  if (typeof window === "undefined" || !isChunkLoadError(error)) return false;
  const now = Date.now();
  let previous = lastAttempt;
  try { previous = Math.max(previous, Number(window.sessionStorage.getItem(recoveryKey)) || 0); } catch { /* Storage can be disabled in embedded previews. */ }
  if (now - previous < retryWindowMs) return false;
  lastAttempt = now;
  try { window.sessionStorage.setItem(recoveryKey, String(now)); } catch { /* Recovery still works without storage. */ }
  window.location.reload();
  return true;
}