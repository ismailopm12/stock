import { Button } from "@/components/ui/button";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, SlidersHorizontal, History, Search, ChevronRight } from "lucide-react";
import { movementsQuery } from "@/lib/inventory";
import { Empty, PageHeader } from "@/components/app/ui";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({ meta: [{ title: "History — Sujon" }, { name: "description", content: "All stock movements." }, { property: "og:title", content: "History — Sujon" }, { property: "og:description", content: "Review incoming, outgoing and adjusted stock." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(movementsQuery()),
  component: HistoryPage,
});

function HistoryPage() {
  const { data: moves } = useSuspenseQuery(movementsQuery());
  const [t, setT] = useState<"all" | "in" | "out" | "adjust">("all");
  const [q, setQ] = useState("");
  const list = moves.filter((m) => (t === "all" || m.type === t) && `${m.items?.name} ${m.batch_no} ${m.note ?? ""}`.toLowerCase().includes(q.toLowerCase()));
  const groups = useMemo(() => {
    const g: Record<string, typeof list> = {};
    list.forEach((m) => { const k = new Date(m.created_at).toDateString(); (g[k] ||= []).push(m); });
    return Object.entries(g);
  }, [list]);

  return (
    <div>
      <PageHeader icon={History} title="History" subtitle={`${moves.length} stock movements`} />
      <div className="px-5">
        <div className="relative"><Search className="absolute left-4 top-4 h-4 w-4 text-muted-foreground" /><Input aria-label="Search history" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search item, batch, note" className="h-12 rounded-xl bg-card pl-11" /></div>
        <div className="mt-3 grid grid-cols-4 gap-1 rounded-xl bg-muted p-1">
          {(["all", "in", "out", "adjust"] as const).map((k) => (
            <Button variant="ghost" key={k} aria-pressed={t === k} onClick={() => setT(k)} className={cn("rounded-xl py-2 text-xs font-semibold ", t === k ? "bg-card shadow-soft" : "text-muted-foreground")}>{k === "all" ? "All" : k === "in" ? "Stock in" : k === "out" ? "Stock out" : "Adjust"}</Button>
          ))}
        </div>
      </div>
      <div className="mt-5 flex items-center justify-between px-5"><h2 className="text-sm font-bold">Movement timeline</h2><span className="text-xs text-muted-foreground">{list.length} records</span></div>
      <div className="mt-4 space-y-6 px-5">
        {groups.map(([day, ms]) => (
          <div key={day}>
            <p className="timeline-date mb-2 text-xs font-semibold text-muted-foreground">{day}</p>
            <div className="overflow-hidden rounded-xl border border-border bg-card divide-y divide-border">
              {ms.map((m) => {
                const Icon = m.type === "in" ? ArrowDownLeft : m.type === "out" ? ArrowUpRight : SlidersHorizontal;
                return (
                  <Link to="/inventory/$id" params={{ id: m.item_id }} key={m.id} className="history-row tap flex items-center gap-3 p-4 transition-colors hover:bg-secondary">
                    <div className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-xl", m.type === "in" ? "bg-success-soft text-success" : m.type === "out" ? "bg-danger-soft text-destructive" : "bg-primary-soft text-accent-foreground")}><Icon className="h-4 w-4" /></div>
                    <div className="min-w-0 flex-1">
                      <p className="break-words text-sm font-bold">{m.items?.name || "Deleted item"}</p>
                      <p className="truncate text-xs text-muted-foreground">Batch {m.batch_no} · {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}{m.note ? ` · ${m.note}` : ""}</p>
                    </div>
                    <div className="max-w-24 text-right"><p className={cn("break-all text-sm font-bold tabular-nums", m.type === "in" ? "text-success" : m.type === "out" ? "text-destructive" : "text-accent-foreground")}>{m.type === "out" ? "−" : m.type === "in" ? "+" : "="}{m.quantity.toLocaleString()}</p><p className="text-[11px] text-muted-foreground">{m.items?.unit}</p></div><ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      {!list.length && <Empty title="No movements" hint="Stock in/out records will appear here." />}
    </div>
  );
}
