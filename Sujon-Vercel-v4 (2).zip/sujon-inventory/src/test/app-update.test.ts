import { describe, expect, it } from "vitest";
import { extractBuildAssets, shouldReloadAssets } from "@/lib/app-update";

const html = [
  '<html><head>',
  '<link rel="stylesheet" href="/assets/index-abc123.css">',
  '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=X&display=swap">',
  '<script type="module" src="/assets/entry-Bx9.js"></script>',
  '</head><body>',
  '<script src="/assets/chunk-x.js"></script>',
  '<script>inline();</script>',
  '<script src="https://cdn.example.com/external.js"></script>',
  '</body></html>',
].join("\n");

describe("app update detection", () => {
  it("extracts same-origin hashed script and stylesheet assets, sorted", () => {
    expect(extractBuildAssets(html)).toEqual([
      "/assets/chunk-x.js",
      "/assets/entry-Bx9.js",
      "/assets/index-abc123.css",
    ]);
  });

  it("ignores inline scripts and external CDN assets", () => {
    expect(
      extractBuildAssets('<script>boom()</script><script src="https://cdn.example.com/a.js"></script>'),
    ).toEqual([]);
  });

  it("returns empty for HTML without hashed assets", () => {
    expect(extractBuildAssets("<html><body>hi</body></html>")).toEqual([]);
  });

  it("only reloads when a previous build is known and different", () => {
    expect(shouldReloadAssets(null, "/assets/a.js")).toBe(false);
    expect(shouldReloadAssets("", "/assets/a.js")).toBe(false);
    expect(shouldReloadAssets("/assets/a.js", "/assets/a.js")).toBe(false);
    expect(shouldReloadAssets("/assets/a.js", "/assets/b.js")).toBe(true);
  });
});
